# Bitcoin Wallet - Projeto de Alta Performance

Sistema de geração e verificação de carteiras Bitcoin.

## Estrutura do Projeto

- **BitcoinWallet-2**: Código-fonte Go para o gerador de carteiras
- **server.py**: Interface web completa para controle
- **simple_server.py**: Versão média do servidor web 
- **basic_server.py**: Versão mínima do servidor web
- **scripts .sh**: Scripts para iniciar e controlar o sistema

## Instruções para VPS

1. Clone este repositório
2. Execute ./start.sh para iniciar o servidor
3. Acesse o endereço IP da VPS na porta 8080

## Desempenho

O sistema é capaz de gerar e verificar mais de 40 milhões de carteiras Bitcoin por segundo em hardware adequado.
