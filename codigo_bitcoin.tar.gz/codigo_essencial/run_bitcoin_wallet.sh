#!/bin/bash

# Script para executar a carteira Bitcoin no Replit - Modo Turbo
# Script adaptado para testes de desempenho (10M chaves/segundo)
# Última atualização: $(date)

cd BitcoinWallet-2

# Compilar código mais recente
echo "Compilando código otimizado para testes de 10M/s..."
go build -o bitcoinwallet -ldflags="-s -w" cmd/main.go

# Verificar se a compilação foi bem-sucedida
if [ ! -f "./bitcoinwallet" ]; then
  echo "Erro: A compilação falhou. O executável 'bitcoinwallet' não foi criado."
  exit 1
fi

# Garantir que o executável tenha permissão de execução
chmod +x ./bitcoinwallet

# Parâmetros otimizados para teste de 10M/s
# Usar todos os CPUs disponíveis para maximizar throughput
CPU=$(nproc)
CARTEIRA=1
MODO=1              # Modo sequencial é o mais rápido para benchmark
SEQUENCIAL=1        # Começar do início
PERCENTUAL=50       # Não utilizado no modo 1
USEDB=0             # Desabilitar DB para teste puro de geração de chaves
NUMRECS=10000000    # Meta de 10M

# Verificar se há argumentos de linha de comando
if [ $# -gt 0 ]; then
  # Processar argumentos de linha de comando
  while [ $# -gt 0 ]; do
    case "$1" in
      -cpu)
        CPU="$2"
        shift 2
        ;;
      -carteira)
        CARTEIRA="$2"
        shift 2
        ;;
      -modo)
        MODO="$2"
        shift 2
        ;;
      -sequencial)
        SEQUENCIAL="$2"
        shift 2
        ;;
      -percentual)
        PERCENTUAL="$2"
        shift 2
        ;;
      -usedb)
        USEDB="$2"
        shift 2
        ;;
      -numrecs)
        NUMRECS="$2"
        shift 2
        ;;
      -help)
        ./bitcoinwallet -help
        exit 0
        ;;
      *)
        echo "Opção desconhecida: $1"
        ./bitcoinwallet -help
        exit 1
        ;;
    esac
  done
fi

# Executar a aplicação com os parâmetros configurados
echo "Executando carteira Bitcoin com os seguintes parâmetros:"
echo "CPUs: $CPU"
echo "Carteira: $CARTEIRA"
echo "Modo: $MODO"

# Mostrar informações do sistema para análise de performance
echo "==== INFORMAÇÕES DO SISTEMA PARA BENCHMARK ===="
echo "CPUs Disponíveis: $(nproc)"
free -h | grep "Mem:" | awk '{print "Memória Total: " $2 ", Usada: " $3 ", Livre: " $4}'
echo "==============================================="

# Executar teste de performance por um período limitado (60 segundos)
echo "Iniciando teste de performance de 60 segundos..."
echo "Meta: 10.000.000 de chaves por segundo"
echo "Modo: TURBO (Otimizações avançadas ativadas)"

# Desativar timer para permitir que o programa execute até encontrar chaves
# Vamos modificar a abordagem para verificar a performance real

# Função para limpar recursos quando o script terminar
cleanup() {
  echo "Teste concluído. Analisando resultados..."
}

# Configurar trap para limpar recursos quando o script for interrompido
trap cleanup EXIT INT TERM

# Iniciar teste baseado no modo
case "$MODO" in
  1)
    echo "Modo 1: Sequencial do início (mais rápido para benchmark)"
    echo "Executando com $CPU CPUs, Lote: 1048576 chaves"
    time ./bitcoinwallet -cpu $CPU -carteira $CARTEIRA -modo $MODO -usedb $USEDB
    ;;
  2)
    echo "Modo 2: Sequencial com percentual"
    echo "  Tipo de sequencial: $SEQUENCIAL"
    echo "  Percentual: $PERCENTUAL"
    time ./bitcoinwallet -cpu $CPU -carteira $CARTEIRA -modo $MODO -sequencial $SEQUENCIAL -percentual $PERCENTUAL -usedb $USEDB
    ;;
  3)
    echo "Modo 3: Geração aleatória"
    echo "  Usar DB: $USEDB"
    echo "  Número de registros: $NUMRECS"
    time ./bitcoinwallet -cpu $CPU -carteira $CARTEIRA -modo $MODO -usedb $USEDB -numrecs $NUMRECS
    ;;
  *)
    echo "Modo inválido: $MODO"
    ./bitcoinwallet -help
    exit 1
    ;;
esac

# Mostrar resumo final do teste
echo "=============== RESUMO DO TESTE ==============="
echo "Duração: 60 segundos"
echo "CPUs utilizados: $CPU"
echo "Modo: $MODO"
echo "UseDB: $USEDB"
echo "=============================================="