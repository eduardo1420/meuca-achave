/**
 * App BTCGO
 * Versão Beta
 */

package main

import (
        app "btcgo/cmd/core"
        "btcgo/cmd/utils"
        "flag"
        "fmt"
        "os"
)

func printHelp() {
        fmt.Println("Uso: ./bitcoinwallet [opções]")
        fmt.Println("\nOpções:")
        fmt.Println("  -cpu N           Número de CPUs para usar (padrão: 1)")
        fmt.Println("  -carteira N      Número da carteira, 1-161 (padrão: 1)")
        fmt.Println("  -modo N          Modo de operação (padrão: 1)")
        fmt.Println("                   1 = Do início")
        fmt.Println("                   2 = Sequencial")
        fmt.Println("                   3 = Random")
        fmt.Println("  -sequencial N    Para modo 2: 1=do início, 2=do range (padrão: 1)")
        fmt.Println("  -percentual N    Para modo 2, percentual do range (padrão: 50)")
        fmt.Println("  -usedb N         Para modo 3: 1=usar DB, 2=sem DB (padrão: 1)")
        fmt.Println("  -numrecs N       Para modo 3, número de registros (padrão: 10000)")
        fmt.Println("  -wallet arquivo  Caminho para arquivo de carteiras (padrão: data/wallets.json)")
        fmt.Println("  -help            Mostra esta ajuda")
        fmt.Println("\nExemplos:")
        fmt.Println("  ./bitcoinwallet -cpu 4 -carteira 10 -modo 1")
        fmt.Println("  ./bitcoinwallet -cpu 2 -carteira 5 -modo 2 -sequencial 2 -percentual 75")
        fmt.Println("  ./bitcoinwallet -cpu 8 -carteira 20 -modo 3 -usedb 1 -numrecs 20000")
        fmt.Println("  ./bitcoinwallet -cpu 4 -carteira 1 -modo 1 -wallet test_data/test_wallets.json")
}

func main() {
        // Define a versão
        version := "v0.6.2"

        // Define flags para argumentos de linha de comando
        cpuPtr := flag.Int("cpu", 0, "Número de CPUs para usar")
        carteiraPtr := flag.Int("carteira", 0, "Número da carteira (1-161)")
        modoPtr := flag.Int("modo", 0, "Modo de operação (1-3)")
        sequencialPtr := flag.Int("sequencial", 1, "Para modo 2: 1=do início, 2=do range")
        percentualPtr := flag.Float64("percentual", 50.0, "Para modo 2, percentual do range")
        usedbPtr := flag.Int("usedb", 1, "Para modo 3: 1=usar DB, 2=sem DB")
        numrecsPtr := flag.Int("numrecs", 10000, "Para modo 3, número de registros")
        walletFilePtr := flag.String("wallet", "data/wallets.json", "Arquivo de carteiras para verificação")
        helpPtr := flag.Bool("help", false, "Mostra ajuda")

        // Parse flags
        flag.Parse()

        // Mostrar ajuda se solicitado
        if *helpPtr {
            printHelp()
            os.Exit(0)
        }

        // Se não houver argumentos, use o modo interativo tradicional
        interactive := *cpuPtr == 0 || *carteiraPtr == 0 || *modoPtr == 0

        utils.ClearConsole()
        utils.Title(version)
        
        if interactive {
            // Modo interativo original
            app.NewApp()
        } else {
            // Modo com argumentos de linha de comando
            app.NewAppWithArgs(*cpuPtr, *carteiraPtr, *modoPtr, *sequencialPtr, *percentualPtr, *usedbPtr, *numrecsPtr, *walletFilePtr)
        }
}
