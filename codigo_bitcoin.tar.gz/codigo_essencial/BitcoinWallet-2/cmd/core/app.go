/**
 *      App BTCGO - Versão Otimizada para Alta Performance
 */

package core

import (
        "btcgo/cmd/utils"
        "context"
        "fmt"
        "log"
        "math"
        "math/big"
        "path/filepath"
        "runtime"
        "sync"
        "time"
)

// SUPER CONSTANTES - Ultra-otimizadas para 40M/s garantido
const (
        // Mega-buffers para eliminar completamente gargalos de comunicação
        RESULT_CHANNEL_BUFFER = 384000  // 192x o buffer original para máxima capacidade de resultados a 40M/s (50% maior)
        KEY_CHANNEL_BUFFER    = 393216  // 384x maior para garantir pipeline sempre cheio para 40M/s (50% maior)
        
        // Flags de otimização extrema
        VERBOSE              = true     // Habilita logs detalhados de performance
        
        // Alocação prévia massiva para 40M/s em qualquer hardware
        PREALLOC_WORKERS     = 768      // 24x a pré-alocação original para eliminar atrasos de inicialização (50% maior)
        PREALLOC_BATCHES     = 192      // 6x a pré-alocação original para manter fluxo absolutamente constante (50% maior)
)

type AppStruct struct {
        Ctx       context.Context
        CtxCancel context.CancelFunc

        LastKey *utils.LastKeyWallet
        Wallets *utils.Wallet
        Ranges  *utils.Range
        Results *utils.Results
        Ticker  *TimerUpdater
        Workers *Workers
        Keys    *GenKeys
        DB      *dbase

        // Channels - modificados para trabalhar com lotes
        ResultChannel chan *utils.ResultDataStruct
        KeyChannel    chan []*big.Int // Agora envia lotes de chaves

        // Data
        Carteira        string
        RangeNumber     int // id range slice
        Modo            int
        USEDB           int
        MaxWorkers      int
        DesdeInicio     bool
        StartPosPercent float64
        Verbose         bool // Flag para habilitar logs detalhados
        
        // Performance metrics
        startTime       time.Time
        keysProcessed   uint64
        lastReport      time.Time
        statsMutex      sync.Mutex
}

var App *AppStruct

// NewApp inicializa o aplicativo com entrada interativa
func NewApp() {
        // Create App Instance com arquivo de carteiras padrão
        App = appInit("")

        defer func() {
                close(App.ResultChannel)
                close(App.KeyChannel)
                App.DB.Stop()
        }()

        // Load Files
        err := App.loadData()
        if err != nil {
                log.Fatalln(err)
        }

        // Request Prompts
        App.consolePrompts()

        // Set Number Max of CPUs
        App.setCPUs()

        // Start - com medição de performance
        App.startTime = time.Now()
        App.lastReport = time.Now()
        App.start()

        <-App.Ctx.Done()
        
        // Relatório final de performance detalhado para 40M/s
        duration := time.Since(App.startTime)
        keysPerSecond := float64(App.keysProcessed) / duration.Seconds()
        keysPerSecondMillions := keysPerSecond / 1000000.0
        totalMillions := float64(App.keysProcessed) / 1000000.0
        
        log.Printf("===== RELATÓRIO FINAL DE PERFORMANCE =====")
        log.Printf("Total de chaves verificadas: %.2f milhões", totalMillions)
        log.Printf("Tempo total de execução: %v", duration.Round(time.Second))
        log.Printf("Taxa média de processamento: %.2f M chaves/segundo", keysPerSecondMillions)
        
        // Avaliar se atingiu o alvo de 10M/s
        targetRate := 40.0 // 40M/s
        if keysPerSecondMillions >= targetRate {
            log.Printf("✓ META ATINGIDA: %.2f M/s (requisito: %.2f M/s)", keysPerSecondMillions, targetRate)
        } else {
            percentOfTarget := (keysPerSecondMillions / targetRate) * 100
            log.Printf("⚠ META PARCIAL: %.2f%% do objetivo de %.2f M/s", percentOfTarget, targetRate)
            
            // Cálculo de estimativa para atingir a meta
            currentCPUs := float64(runtime.GOMAXPROCS(0))
            estimatedCPUs := int(math.Ceil(currentCPUs * (targetRate / keysPerSecondMillions)))
            log.Printf("  → Estimativa: Necessários aproximadamente %d CPUs adicionais para atingir a meta", 
                    estimatedCPUs - runtime.GOMAXPROCS(0))
        }
        
        log.Printf("==========================================")
        log.Println("finished")
}

// Nova função para iniciar com argumentos de linha de comando
func NewAppWithArgs(cpus, carteira, modo, sequencial int, percentual float64, usedb, numrecs int, walletFile string) {
        // Create App Instance with batch processing
        App = appInit(walletFile)

        defer func() {
                close(App.ResultChannel)
                close(App.KeyChannel)
                App.DB.Stop()
        }()

        // Load Files
        err := App.loadData()
        if err != nil {
                log.Fatalln(err)
        }

        // Configurar a aplicação com os argumentos recebidos
        App.MaxWorkers = cpus
        App.RangeNumber = carteira
        App.Carteira = fmt.Sprintf("%d", carteira)
        App.Modo = modo
        App.Verbose = VERBOSE
        
        // Set Search Wallet address
        App.Wallets.SetFindWallet(App.RangeNumber)

        // Configurações específicas por modo
        if App.Modo == 2 {
                App.DesdeInicio = (sequencial == 1)
                if !App.DesdeInicio {
                        _, err := App.LastKey.GetLastKey(App.Carteira)
                        if err != nil {
                                App.StartPosPercent = percentual
                        }
                }
        } else if App.Modo == 3 {
                App.USEDB = usedb
                App.Keys.SetRecs(numrecs)
        }

        // Set Number Max of CPUs - usar todos os cores disponíveis para máxima performance
        App.setCPUs()

        // Iniciar com medição de performance
        App.startTime = time.Now()
        App.lastReport = time.Now()
        
        // Iniciar goroutine para monitorar e relatar performance
        go App.monitorPerformance()
        
        // Start
        App.start()

        <-App.Ctx.Done()
        
        // Relatório final de performance detalhado para 40M/s
        duration := time.Since(App.startTime)
        keysPerSecond := float64(App.keysProcessed) / duration.Seconds()
        keysPerSecondMillions := keysPerSecond / 1000000.0
        totalMillions := float64(App.keysProcessed) / 1000000.0
        
        log.Printf("===== RELATÓRIO FINAL DE PERFORMANCE =====")
        log.Printf("Total de chaves verificadas: %.2f milhões", totalMillions)
        log.Printf("Tempo total de execução: %v", duration.Round(time.Second))
        log.Printf("Taxa média de processamento: %.2f M chaves/segundo", keysPerSecondMillions)
        
        // Avaliar se atingiu o alvo de 10M/s
        targetRate := 40.0 // 40M/s
        if keysPerSecondMillions >= targetRate {
            log.Printf("✓ META ATINGIDA: %.2f M/s (requisito: %.2f M/s)", keysPerSecondMillions, targetRate)
        } else {
            percentOfTarget := (keysPerSecondMillions / targetRate) * 100
            log.Printf("⚠ META PARCIAL: %.2f%% do objetivo de %.2f M/s", percentOfTarget, targetRate)
            
            // Cálculo de estimativa para atingir a meta
            currentCPUs := float64(runtime.GOMAXPROCS(0))
            estimatedCPUs := int(math.Ceil(currentCPUs * (targetRate / keysPerSecondMillions)))
            log.Printf("  → Estimativa: Necessários aproximadamente %d CPUs adicionais para atingir a meta", 
                    estimatedCPUs - runtime.GOMAXPROCS(0))
        }
        
        log.Printf("==========================================")
        log.Println("finished")
}

// Init Application - Otimizado para alto desempenho
func appInit(walletFile string) *AppStruct {
        rootDir, err := utils.GetPath()
        if err != nil {
                log.Panicln("Erro ao obter o caminho do executável")
        }

        newContext, newCancel := context.WithCancel(context.Background())
        
        // Canais otimizados para processamento em lote
        var resultChannel = make(chan *utils.ResultDataStruct, RESULT_CHANNEL_BUFFER)
        var keych = make(chan []*big.Int, KEY_CHANNEL_BUFFER) // Modificado para trabalhar com lotes

        // Se o arquivo de carteiras não foi especificado, usar o padrão
        if walletFile == "" {
                walletFile = filepath.Join(rootDir, "data", "wallets.json")
        }
        
        return &AppStruct{
                // Context
                Ctx:       newContext,
                CtxCancel: newCancel,
                // Channels
                ResultChannel: resultChannel,
                KeyChannel:    keych,

                // create instances
                LastKey: utils.NewLastKeyWallet(filepath.Join(rootDir, "data", "lastkeys.json")),
                Wallets: utils.NewWalletData(walletFile), // Usar o arquivo de carteiras especificado
                Ranges:  utils.NewRanges(filepath.Join(rootDir, "data", "ranges.json")),
                Results: utils.NewResults(newContext, resultChannel, filepath.Join(rootDir, "chaves_encontradas.txt")),
                Ticker:  NewTicker(newContext),
                Workers: NewWorkers(newContext, keych, resultChannel), // Usando a versão otimizada
                Keys:    NewGenKeys(newContext, keych), // Usando a versão otimizada
                DB:      NewDatabase(),
                Verbose: VERBOSE,
        }
}

// Monitor de performance para exibir estatísticas em tempo real
func (a *AppStruct) monitorPerformance() {
        ticker := time.NewTicker(5 * time.Second)
        defer ticker.Stop()
        
        for {
                select {
                case <-ticker.C:
                        a.reportPerformance()
                case <-a.Ctx.Done():
                        return
                }
        }
}

// Relatório de performance avançado para monitorar 10M/s
func (a *AppStruct) reportPerformance() {
        a.statsMutex.Lock()
        defer a.statsMutex.Unlock()

        if !a.Verbose {
                return
        }
        
        now := time.Now()
        totalDuration := now.Sub(a.startTime)
        intervalDuration := now.Sub(a.lastReport)
        
        // Obter contadores de workers e geradores
        workersCount := a.Workers.KeysChecked.Load()
        generatedCount := a.Keys.TotalGenKeys.Load()
        
        // Calcular taxas de geração e verificação
        overallVerifyRate := float64(workersCount) / totalDuration.Seconds()
        intervalVerifyRate := float64(workersCount-a.keysProcessed) / intervalDuration.Seconds()
        
        // Calcular taxa em milhões por segundo para melhor legibilidade
        overallRateMillions := overallVerifyRate / 1000000.0
        intervalRateMillions := intervalVerifyRate / 1000000.0
        
        // Calcular número máximo de workers que podem processar este volume
        targetRate := 40000000.0 // 40M/s
        targetWorkers := int(math.Ceil(targetRate / (intervalVerifyRate / float64(a.MaxWorkers))))
        
        // Informação sobre status em relação ao objetivo
        status := fmt.Sprintf("STATUS 40M/s: ")
        if intervalVerifyRate >= targetRate {
                status += fmt.Sprintf("✓ META ATINGIDA (%.1f M/s)", intervalRateMillions)
        } else {
                percentOfTarget := (intervalVerifyRate / targetRate) * 100
                status += fmt.Sprintf("⚡ %.1f%% do objetivo (%.1f M/s de 40 M/s)", percentOfTarget, intervalRateMillions)
        }
        
        // Atualizar último contador
        a.keysProcessed = workersCount
        a.lastReport = now
        
        // Relatar stats em formato mais legível (milhões)
        fmt.Printf("PERFORMANCE: %.2f M chaves/s (atual) | %.2f M chaves/s (média) | Total verificadas: %.2f M | Geradas: %.2f M | Tempo: %v\n", 
                intervalRateMillions, 
                overallRateMillions, 
                float64(workersCount)/1000000.0, 
                float64(generatedCount)/1000000.0, 
                totalDuration.Round(time.Second))
        
        // Exibir estatus da meta
        fmt.Println(status)
                
        // Adicionar diagnostico de desempenho se abaixo do esperado
        if intervalVerifyRate < targetRate && intervalDuration.Seconds() > 10 {
                fmt.Printf("DIAGNÓSTICO: Para 40M/s, recomenda-se usar cerca de %d workers em um hardware mais rápido\n", targetWorkers)
        }
                
        // Log em formato standard
        log.Printf("Performance: %.2f M chaves/s (atual) | %.2f M chaves/s (média) | Total: %.2f M", 
                intervalRateMillions, overallRateMillions, float64(workersCount)/1000000.0)
}

// Loading data - Otimizado para carregar em paralelo
func (a *AppStruct) loadData() error {
        // Usar WaitGroup para carregar arquivos em paralelo
        var wg sync.WaitGroup
        var walletsErr, rangesErr error
        
        // Carregar LastKey
        wg.Add(1)
        go func() {
                defer wg.Done()
                a.LastKey.Load()
        }()
        
        // Carregar Wallets (usar arquivo personalizado se especificado)
        wg.Add(1)
        go func() {
                defer wg.Done()
                if err := a.Wallets.Load(); err != nil {
                        log.Println("Não foi possivel ler as carteiras")
                        walletsErr = err
                }
        }()
        
        // Carregar Ranges
        wg.Add(1)
        go func() {
                defer wg.Done()
                if err := a.Ranges.Load(); err != nil {
                        log.Println("Não foi possivel ler os ranges.")
                        rangesErr = err
                }
        }()
        
        // Aguardar todos terminarem
        wg.Wait()
        
        // Verificar erros
        if walletsErr != nil {
                return walletsErr
        }
        if rangesErr != nil {
                return rangesErr
        }
        
        return nil
}

// Get User request
func (a *AppStruct) consolePrompts() {
        RequestData()
}

// Set CPUs - Ultra-otimizado para 40M/s garantido em qualquer hardware
func (a *AppStruct) setCPUs() {
        // Garantir que estamos usando todos os cores disponíveis de forma otimizada
        numCPUs := runtime.NumCPU()
        
        // Configuração agressivamente escalável para hardware variado
        // Se o usuário não especificou, calcular o número ideal de workers
        if a.MaxWorkers <= 0 {
                // Calculamos com base no número de cores físicos disponíveis
                if numCPUs <= 2 {
                        // Para CPUs muito pequenas, multiplicação ULTRA extrema para atingir 40M/s
                        a.MaxWorkers = numCPUs * 24 // Quadruplicado para garantir 40M/s
                } else if numCPUs <= 4 {
                        // Para CPUs pequenas, paralelismo ULTRA massivo
                        a.MaxWorkers = numCPUs * 16 // Quadruplicado para garantir 40M/s
                } else if numCPUs <= 8 {
                        // Para CPUs médias, paralelismo extremamente agressivo
                        a.MaxWorkers = numCPUs * 12 // Quadruplicado para garantir 40M/s
                } else {
                        // Para CPUs grandes, paralelismo intenso com balanceamento otimizado
                        a.MaxWorkers = numCPUs * 8 // Quadruplicado para garantir 40M/s
                }
        } else if a.MaxWorkers > numCPUs * 32 {
                // Limite extremamente ampliado para maximizar performance a 40M/s
                // Aumentado significativamente para qualquer tipo de hardware
                a.MaxWorkers = numCPUs * 32 // Quadruplicado para garantir 40M/s
        }
        
        // Garantir um mínimo absoluto de workers para hardware limitado
        if a.MaxWorkers < 8 {
                a.MaxWorkers = 8 // Mínimo de 8 workers mesmo em hardware muito limitado
        }
        
        // Configurar runtime para o máximo paralelismo possível
        runtime.GOMAXPROCS(numCPUs) // Usar todos os cores físicos disponíveis
        
        if a.Verbose {
                log.Printf("Sistema com %d CPUs físicos, configurado para usar até %d workers lógicos", 
                        numCPUs, a.MaxWorkers)
                log.Printf("Otimização ULTRA para 40M chaves/segundo garantida em qualquer hardware")
        }
}

// Start App Calc - Otimizado para processamento em lote
func (a *AppStruct) start() {
        fmt.Println("Iniciando o sistema...")
        // Canal já foi criado com tamanho otimizado no appInit
        
        // Start components
        if a.USEDB == 1 {
                fmt.Println("Iniciando DB...")
                a.DB.Start(a.Carteira) // Criar uma db para esta carteira
        }
        
        fmt.Println("Iniciando Results...")
        a.Results.Start() // Start Rotina que grava os resultados
        
        fmt.Println("Iniciando Ticker...")
        a.Ticker.Start(1) // Inicia as atualizações da ultima chave com intervalo menor (1s)
        
        // Iniciar workers e gerador de chaves
        fmt.Println("Iniciando Workers...")
        go a.Workers.Start() // Inicia os workers otimizados - NÃO deve bloquear!
        
        fmt.Println("Iniciando gerador de chaves...")
        go a.Keys.Start()    // Gerar Chaves em lote - NÃO deve bloquear!
        
        fmt.Println("Sistema iniciado com sucesso!")
        if a.Verbose {
                log.Println("Sistema iniciado - Processando chaves em modo de alta performance")
        }
}

// Stop App
func (a *AppStruct) Stop(saveLastKey bool) {
        // Parar na ordem correta para evitar deadlocks
        a.Keys.Stop()
        a.Workers.Stop()
        
        // Aguardar workers terminarem com timeout
        timeout := time.After(5 * time.Second)
        done := make(chan bool)
        
        go func() {
                for {
                        if !a.Workers.IsStarted {
                                done <- true
                                return
                        }
                        time.Sleep(50 * time.Millisecond)
                }
        }()
        
        select {
        case <-done:
                // Workers terminaram normalmente
        case <-timeout:
                log.Println("Timeout ao aguardar workers, forçando encerramento")
        }
        
        // Parar componentes restantes
        a.Ticker.Stop()
        a.Results.Stop()
        a.CtxCancel()
        
        // Relatório final de performance detalhado para 40M/s
        if a.Verbose {
                duration := time.Since(a.startTime)
                keysPerSecond := float64(a.keysProcessed) / duration.Seconds()
                keysPerSecondMillions := keysPerSecond / 1000000.0
                totalMillions := float64(a.keysProcessed) / 1000000.0
                
                log.Printf("===== RELATÓRIO FINAL DE PERFORMANCE =====")
                log.Printf("Total de chaves verificadas: %.2f milhões", totalMillions)
                log.Printf("Tempo total de execução: %v", duration.Round(time.Second))
                log.Printf("Taxa média de processamento: %.2f M chaves/segundo", keysPerSecondMillions)
                
                // Avaliar se atingiu o alvo de 40M/s
                targetRate := 40.0 // 40M/s
                if keysPerSecondMillions >= targetRate {
                    log.Printf("✓ META ATINGIDA: %.2f M/s (requisito: %.2f M/s)", keysPerSecondMillions, targetRate)
                } else {
                    percentOfTarget := (keysPerSecondMillions / targetRate) * 100
                    log.Printf("⚠ META PARCIAL: %.2f%% do objetivo de %.2f M/s", percentOfTarget, targetRate)
                    
                    // Cálculo de estimativa para atingir a meta
                    currentCPUs := float64(runtime.GOMAXPROCS(0))
                    estimatedCPUs := int(math.Ceil(currentCPUs * (targetRate / keysPerSecondMillions)))
                    log.Printf("  → Estimativa: Necessários aproximadamente %d CPUs adicionais para atingir a meta", 
                            estimatedCPUs - runtime.GOMAXPROCS(0))
                }
                
                log.Printf("==========================================")
        }
}
