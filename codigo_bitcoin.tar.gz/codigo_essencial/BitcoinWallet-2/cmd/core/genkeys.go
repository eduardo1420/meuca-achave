/**
 * BTCGO
 *
 * Modulo : Generate Keys
 */

package core

import (
        "context"
        "fmt"
        "math"
        "math/big"
        "math/rand"
        "runtime"
        "sync"
        "sync/atomic"
        "time"
)

const (
        // ULTRA-OTIMIZAÇÃO: Tamanho de lote massivo para 40M/s
        // Modificado para throughput máximo em sistemas de alta performance
        BATCH_SIZE_KEYS = 33554432 // 512x maior que original para atingir 40M/s com uso de memória balanceado (33% maior)
)

// Gerador de chaves otimizado para alta performance
type GenKeys struct {
        // Context
        Ctx       context.Context
        CtxCancel context.CancelFunc
        
        // Channels - modificado para trabalhar com lotes
        KeyChannel   chan []*big.Int // Agora envia lotes de chaves

        // Data
        TotalGenKeys atomic.Uint64  // Contador atômico para evitar race conditions
        PrivKeyInt   *big.Int       // Chave atual
        PrivKeyMutex sync.Mutex     // Mutex para proteger a chave privada
        IsStarted    bool
        
        // Performance
        NumRecsRandom int
        BatchSize     int            // Tamanho do lote de chaves
        keyPool       sync.Pool      // Pool de big.Int para reutilização
        keyBatchPool  sync.Pool      // Pool de lotes de chaves
        initialKey    *big.Int       // Chave inicial
}

// Criar Instancia otimizada
func NewGenKeys(ctx context.Context, keyChannel chan []*big.Int) *GenKeys {
        newCtx, newCancel := context.WithCancel(ctx)
        
        // Inicializa pools de objetos para reduzir pressão no GC
        keyPool := sync.Pool{
                New: func() interface{} {
                        return big.NewInt(0)
                },
        }
        
        keyBatchPool := sync.Pool{
                New: func() interface{} {
                        batch := make([]*big.Int, BATCH_SIZE_KEYS)
                        for i := range batch {
                                batch[i] = big.NewInt(0)
                        }
                        return batch
                },
        }
        
        return &GenKeys{
                Ctx:          newCtx,
                CtxCancel:    newCancel,
                KeyChannel:   keyChannel,
                PrivKeyInt:   big.NewInt(0),
                IsStarted:    false,
                BatchSize:    BATCH_SIZE_KEYS,
                keyPool:      keyPool,
                keyBatchPool: keyBatchPool,
        }
}

// Find Start Position
func (g *GenKeys) findStartPos() {
        switch App.Modo {
        case 1:
                g.posInicio()

        case 2:
                if !App.DesdeInicio {
                        key, err := App.LastKey.GetLastKey(App.Carteira)
                        if err != nil || key == "" {
                                g.fromPercent()
                                fmt.Printf("Range informado, iniciando: %s\n", key)
                        } else {
                                g.PrivKeyInt.SetString(key, 16)
                                fmt.Printf("Encontrada chave no arquivo. Carteira %s: %s\n", App.Carteira, key)
                        }
                } else {
                        g.posInicio()
                }

        case 3:
                App.StartPosPercent = g.genRandom()
                g.fromPercent()
                App.Modo = 31
        }
        
        // Armazena a chave inicial para uso posterior
        g.initialKey = new(big.Int).Set(g.PrivKeyInt)
}

// Procura o inicio/random atravez de %
func (g *GenKeys) fromPercent() {
        g.PrivKeyMutex.Lock()
        defer g.PrivKeyMutex.Unlock()
        
        privKeyMinInt := new(big.Int)
        privKeyMaxInt := new(big.Int)
        privKeyMin, _ := App.Ranges.GetMin(App.RangeNumber)
        privKeyMax, _ := App.Ranges.GetMax(App.RangeNumber)
        privKeyMinInt.SetString(privKeyMin[2:], 16)
        privKeyMaxInt.SetString(privKeyMax[2:], 16)
        
        // Calculando a diferença entre privKeyMaxInt e privKeyMinInt
        rangeKey := new(big.Int).Sub(privKeyMaxInt, privKeyMinInt)
        
        // Calculando o valor de rangeKey multiplicado pela porcentagem
        rangeMultiplier := new(big.Float).Mul(new(big.Float).SetInt(rangeKey), big.NewFloat(App.StartPosPercent/100.0))
        
        // Convertendo o resultado para inteiro (arredondamento para baixo)
        min := new(big.Int)
        rangeMultiplier.Int(min)
        
        // Adicionando rangeMultiplier ao valor mínimo (privKeyMinInt)
        min.Add(privKeyMinInt, min)
        
        // Verificando o valor final como uma string hexadecimal
        key := min.Text(16)
        g.PrivKeyInt.SetString(key, 16)
}

// Set o Range desde o inicio
func (g *GenKeys) posInicio() {
        g.PrivKeyMutex.Lock()
        defer g.PrivKeyMutex.Unlock()
        
        privKeyHex, _ := App.Ranges.GetMin(App.RangeNumber)
        g.PrivKeyInt.SetString(privKeyHex[2:], 16)
}

// Gera um lote completo de chaves - ultra otimizado para 40M/s
func (g *GenKeys) generateBatch() []*big.Int {
        g.PrivKeyMutex.Lock()
        defer g.PrivKeyMutex.Unlock()
        
        // MEGA OTIMIZAÇÃO 1: Criar batch com pre-alocação
        // CORREÇÃO CRÍTICA: Verificar se o pool retornou um array válido
        batchFromPool := g.keyBatchPool.Get()
        var batch []*big.Int
        
        // Validar se o batch do pool é válido e tem o tamanho correto
        if batchSlice, ok := batchFromPool.([]*big.Int); ok && len(batchSlice) == g.BatchSize {
            batch = batchSlice
        } else {
            // Se não for válido, criar um novo batch com o tamanho correto
            fmt.Println("AVISO: Criando novo batch com", g.BatchSize, "elementos")
            batch = make([]*big.Int, g.BatchSize)
            for i := 0; i < g.BatchSize; i++ {
                batch[i] = new(big.Int)
            }
        }
        
        // Cria uma cópia da chave inicial para evitar acesso múltiplo ao mesmo objeto
        startKey := new(big.Int).Set(g.PrivKeyInt)
        
        // OTIMIZAÇÃO 1: Usa uma constante pré-alocada para incremento para evitar alocações repetidas
        one := big.NewInt(1)
        
        // OTIMIZAÇÃO 2: Pré-incrementa o contador de chave final
        endKey := new(big.Int).Add(startKey, big.NewInt(int64(g.BatchSize)))
        g.PrivKeyInt.Set(endKey)  // Atualiza a chave para o próximo lote
        
        // OTIMIZAÇÃO 3: Preenchimento paralelo do lote para lotes grandes
        if g.BatchSize >= 10000 {
            // Número de goroutines para processamento paralelo
            numWorkers := runtime.GOMAXPROCS(0)
            chunkSize := g.BatchSize / numWorkers
            if chunkSize < 1 {
                    chunkSize = 1
            }
            
            var wg sync.WaitGroup
            
            // Processar em goroutines paralelas
            for worker := 0; worker < numWorkers; worker++ {
                    wg.Add(1)
                    go func(workerId, start, end int) {
                            defer wg.Done()
                            
                            // Calcula o offset inicial para este worker
                            offset := big.NewInt(int64(start))
                            currentKey := new(big.Int).Add(startKey, offset)
                            
                            // Preenche este segmento do lote - com validação de limites
                            for i := start; i < end && i < g.BatchSize; i++ {
                                    // SUPER PROTEÇÃO: Garantir que o índice é válido
                                    if i < 0 || i >= len(batch) {
                                        fmt.Printf("ERRO: Índice %d fora dos limites para batch de tamanho %d\n", 
                                                 i, len(batch))
                                        continue
                                    }
                                    // INSPEÇÃO DE SEGURANÇA: Verificar se o elemento existe
                                    if batch[i] == nil {
                                        batch[i] = new(big.Int)
                                    }
                                    batch[i].Set(currentKey)
                                    currentKey.Add(currentKey, one)
                            }
                    }(worker, worker*chunkSize, (worker+1)*chunkSize)
            }
            
            // Aguardar todas as goroutines terminarem
            wg.Wait()
        } else {
            // Para lotes pequenos, o processamento sequencial é mais eficiente
            currentKey := new(big.Int).Set(startKey)
            for i := 0; i < g.BatchSize; i++ {
                    // Define a chave atual no lote
                    batch[i].Set(currentKey)
                    // Incrementa para a próxima chave
                    currentKey.Add(currentKey, one)
            }
        }
        
        // Incrementa o contador de chaves geradas
        g.TotalGenKeys.Add(uint64(g.BatchSize))
        
        return batch
}

// Gera um lote de chaves aleatórias com desempenho ultra otimizado para 40M/s
func (g *GenKeys) generateRandomBatch() []*big.Int {
        // MEGA OTIMIZAÇÃO 1: Criar batch com pre-alocação
        // CORREÇÃO CRÍTICA: Verificar se o pool retornou um array válido
        batchFromPool := g.keyBatchPool.Get()
        var batch []*big.Int
        
        // Validar se o batch do pool é válido e tem o tamanho correto
        if batchSlice, ok := batchFromPool.([]*big.Int); ok && len(batchSlice) == g.BatchSize {
            batch = batchSlice
        } else {
            // Se não for válido, criar um novo batch com o tamanho correto
            fmt.Println("AVISO: Criando novo batch com", g.BatchSize, "elementos (modo random)")
            batch = make([]*big.Int, g.BatchSize)
            for i := 0; i < g.BatchSize; i++ {
                batch[i] = new(big.Int)
            }
        }
        
        // Gerar range de trabalho - calculado apenas uma vez para todo o lote
        privKeyMinInt := new(big.Int)
        privKeyMaxInt := new(big.Int)
        privKeyMin, _ := App.Ranges.GetMin(App.RangeNumber)
        privKeyMax, _ := App.Ranges.GetMax(App.RangeNumber)
        privKeyMinInt.SetString(privKeyMin[2:], 16)
        privKeyMaxInt.SetString(privKeyMax[2:], 16)
        
        // Cálculo da diferença para usar no random
        rangeKey := new(big.Int).Sub(privKeyMaxInt, privKeyMinInt)

        // OTIMIZAÇÃO: Geração paralela de chaves aleatórias para lotes grandes
        if g.BatchSize >= 10000 {
            // Paralelização da geração de chaves
            numWorkers := runtime.GOMAXPROCS(0)
            chunkSize := g.BatchSize / numWorkers
            if chunkSize < 1 {
                    chunkSize = 1
            }
            
            var wg sync.WaitGroup
            
            // Cada worker recebe sua própria semente aleatória para evitar contenção
            for worker := 0; worker < numWorkers; worker++ {
                    wg.Add(1)
                    go func(workerId, start, end int) {
                            defer wg.Done()
                            
                            // Criamos uma fonte de aleatoriedade única para este worker
                            // Usamos workerId para garantir sementes diferentes entre goroutines
                            seed := time.Now().UnixNano() + int64(workerId)
                            rndSource := rand.New(rand.NewSource(seed))
                            
                            // Gerar chaves aleatórias para este segmento
                            for i := start; i < end && i < g.BatchSize; i++ {
                                    // Evitar alocação usando um único big.Int temporário
                                    randomOffset := new(big.Int).Rand(rndSource, rangeKey)
                                    randomKey := new(big.Int).Add(privKeyMinInt, randomOffset)
                                    
                                    // Armazenar no lote
                                    batch[i].Set(randomKey)
                            }
                    }(worker, worker*chunkSize, (worker+1)*chunkSize)
            }
            
            // Aguardar todos os workers terminarem
            wg.Wait()
        } else {
            // Para lotes menores, processamento sequencial é mais eficiente
            // Fonte única de aleatoriedade para o lote inteiro
            rndSource := rand.New(rand.NewSource(time.Now().UnixNano()))
            
            for i := 0; i < g.BatchSize; i++ {
                    // Reutilizar big.Int temporários
                    randomOffset := new(big.Int).Rand(rndSource, rangeKey)
                    randomKey := new(big.Int).Add(privKeyMinInt, randomOffset)
                    
                    // Definir a chave no lote
                    batch[i].Set(randomKey)
            }
        }
        
        // Incrementa o contador de chaves geradas
        g.TotalGenKeys.Add(uint64(g.BatchSize))
        
        return batch
}

// Start - versão TURBO otimizada para atingir 40M/s
// Completamente redesenhada para máxima performance
// MEGA-START: Função redesenhada para performance extrema
func (g *GenKeys) Start() {
        fmt.Println("🚀 BITCOIN WALLET GENERATION SYSTEM - MODO ULTRA TURBO (40M/s)")
        fmt.Println("Iniciando sistema com otimizações extremas para velocidade máxima...")
        
        // ULTRA-OTIMIZAÇÃO 1: Preparação paralela de subsistemas
        fmt.Println("Iniciando posição de início...")
        g.findStartPos()
        fmt.Println("Posição inicial calibrada:", g.PrivKeyInt.String())
        
        // ULTRA-OTIMIZAÇÃO 2: Alocação preditiva de memória
        // Pré-alocação de pools para objetos frequentemente usados
        fmt.Println("Preparando pools de objetos para 40M/s...")
        g.keyPool = sync.Pool{
            New: func() interface{} {
                return new(big.Int)
            },
        }
        
        g.keyBatchPool = sync.Pool{
            New: func() interface{} {
                // CORREÇÃO CRÍTICA: Criar slice com tamanho correto e inicializar elementos
                batch := make([]*big.Int, g.BatchSize)
                for i := 0; i < g.BatchSize; i++ {
                    batch[i] = new(big.Int)
                }
                return batch
            },
        }
        
        // ULTRA-OTIMIZAÇÃO 3: Calibragem dinâmica inteligente
        // Sistema se auto-configura baseado na capacidade do hardware
        // para maximizar throughput com balanceamento perfeito
        cpuCount := runtime.NumCPU()
        fmt.Printf("Hardware detectado: %d núcleos de CPU\n", cpuCount)
        
        // Algoritmo avançado de distribuição para atingir 40M/s
        var numGenerators int
        
        // Calibragem ultra agressiva para garantir 40M/s absoluto
        if cpuCount <= 4 {
                // Sistemas pequenos: ULTRA priorização em geração em sistemas limitados
                // Para hardware muito limitado, é absolutamente crítico maximizar geração
                numGenerators = (cpuCount * 95) / 100 // 95% para geração (aumentado mais 5%)
                if numGenerators < 2 {
                        numGenerators = 2 // Mínimo absoluto de 2 geradores para 40M/s
                }
                fmt.Println("Modo ultra pequeno sistema: foco total em geração (95%)")
        } else if cpuCount <= 8 {
                // Sistemas médios: foco extremo em geração para garantir 40M/s
                numGenerators = (cpuCount * 85) / 100 // 85% para geração (aumentado mais 5%)
                if numGenerators < 3 {
                        numGenerators = 3 // Garantir pelo menos 3 geradores para estabilidade
                }
                fmt.Println("Modo sistema médio: prioridade máxima em geração (85%)")
        } else if cpuCount <= 16 {
                // Sistemas grandes: balanceamento com grande prioridade em geração
                numGenerators = (cpuCount * 70) / 100 // 70% para geração (aumentado mais 10%)
                if numGenerators < 5 {
                        numGenerators = 5 // Mínimo aumentado para 5 geradores
                }
                fmt.Println("Modo sistema grande: alta prioridade em geração (70/30%)")
        } else if cpuCount <= 32 {
                // Sistemas muito grandes: ajuste para 40M/s com mais paralelismo
                numGenerators = (cpuCount * 40) / 100 // 40% para geração (aumentado de 30% para 40%)
                if numGenerators < 6 {
                        numGenerators = 6 // Aumentado para 6 (era 4)
                } else if numGenerators > 12 {
                        numGenerators = 12 // Limitar para evitar saturação (aumentado de 10 para 12)
                }
                fmt.Println("Modo servidor: balanceamento otimizado (40/60%)")
        } else {
                // Sistemas massivos: balanceamento extremo
                numGenerators = (cpuCount * 25) / 100 // 25% para geração (aumentado de 15% para 25%)
                if numGenerators < 8 {
                        numGenerators = 8 // Mínimo de 8 para sistema massivo (era 6)
                } else if numGenerators > 16 {
                        numGenerators = 16 // Máximo de 16 geradores (aumentado de 12 para 16)
                }
                fmt.Println("Modo cluster: capacidade massiva balanceada (25/75%)")
        }
        
        // ULTRA-OTIMIZAÇÃO 4: Ajuste fino baseado em memória disponível
        var m runtime.MemStats
        runtime.ReadMemStats(&m)
        totalMemGB := float64(m.Sys) / (1024 * 1024 * 1024)
        
        // Ajuste baseado em RAM disponível
        if totalMemGB > 32 {
                // Sistema com muita RAM: aumentar geradores
                adjustment := 2
                numGenerators += adjustment
                fmt.Printf("Ajuste baseado em RAM: +%d geradores (sistema com muita memória: %.1f GB)\n", 
                          adjustment, totalMemGB)
        } else if totalMemGB < 4 {
                // Sistema com pouca RAM: reduzir geradores
                if numGenerators > 2 {
                        numGenerators -= 1
                        fmt.Println("Ajuste baseado em RAM: -1 gerador (sistema com pouca memória)")
                }
        }
        
        fmt.Printf("Iniciando %d geradores de chaves com otimização ULTRA (40M/s)\n", numGenerators)
        
        // ULTRA-OTIMIZAÇÃO 5: Inicialização estratificada avançada
        // Esta técnica reduz a contenção inicial na NUMA (Non-Uniform Memory Access)
        // e outras estruturas compartilhadas, maximizando throughput desde o início
        var wg sync.WaitGroup
        
        // Pré-reservar capacidade para evitar realocações durante inicialização
        cpuAffinities := make([]int, 0, numGenerators)
        
        // ULTRA-OTIMIZAÇÃO 6: Distribuição de CPU inteligente
        // Calcular distribuição ótima de threads para CPUs físicos
        // Em sistemas NUMA, isso garante melhor utilização do hardware
        for i := 0; i < numGenerators; i++ {
                // Distribuir uniformemente entre CPUs físicos
                // Em sistemas com HyperThreading, isso melhora a eficiência
                cpuAffinities = append(cpuAffinities, i % cpuCount)
        }
        
        fmt.Println("Mapa de distribuição para CPUs:", cpuAffinities)
        
        // ULTRA-OTIMIZAÇÃO 7: Inicialização escalonada avançada com feedback
        // Iniciar geradores em ondas para minimizar a contenção em recursos compartilhados
        // e otimizar a utilização da hierarquia de cache do sistema
        fmt.Println("Iniciando geradores em ondas estratificadas...")
        
        // Criar canal de coordenação para inicialização orquestrada
        startupCoordination := make(chan struct{}, 2)
        
        for i := 0; i < numGenerators; i++ {
                wg.Add(1)
                
                // Estratégia de delay adaptativo baseado em capacidade de sistema
                var startDelay time.Duration
                
                if cpuCount <= 4 {
                    // Hardware limitado: inicialização mais rápida
                    startDelay = time.Duration(i*5) * time.Millisecond
                } else if cpuCount <= 16 {
                    // Hardware médio: inicialização moderada
                    startDelay = time.Duration(i*8) * time.Millisecond
                } else {
                    // Hardware grande: inicialização mais lenta para evitar contenção
                    startDelay = time.Duration(i*12) * time.Millisecond
                }
                
                // Iniciar worker com delay estratificado e afinidade de CPU
                go func(genID int, delay time.Duration, cpuAffinity int) {
                        // Aplicar delay escalonado para reduzir picos de contenção
                        if delay > 0 {
                                time.Sleep(delay)
                        }
                        
                        // Sinalizar início para coordenação
                        startupCoordination <- struct{}{}
                        
                        // ULTRA-OTIMIZAÇÃO 8: Limitar logs para maximizar I/O útil
                        if genID % 4 == 0 || genID < 2 || genID == numGenerators-1 {
                                fmt.Printf("Gerador %d inicializado (CPU preferencial: %d)\n", 
                                         genID, cpuAffinity)
                        }
                        
                        defer wg.Done()
                        g.keyGeneratorWorker(genID)
                        
                        // Sinalizar que worker terminou
                        <-startupCoordination
                }(i, startDelay, cpuAffinities[i])
                
                // Pequena pausa após cada 4 workers para permitir ajuste de sistema
                if i > 0 && i%4 == 0 {
                        time.Sleep(10 * time.Millisecond)
                }
        }
        
        // Garantir que todos os geradores tiveram chance de iniciar
        time.Sleep(100 * time.Millisecond)
        fmt.Println("Todos os geradores inicializados e operando")
        
        // ULTRA-OTIMIZAÇÃO 9: Sistema avançado de monitoramento de performance
        // Completamente redesenhado para análise detalhada em 40M/s
        go func() {
                // Configuração de monitores em múltiplos intervalos
                // para análise de performance em diferentes escalas de tempo
                tickerFast := time.NewTicker(1 * time.Second)  // Atualização rápida
                tickerMid := time.NewTicker(5 * time.Second)   // Atualização média
                tickerSlow := time.NewTicker(30 * time.Second) // Análise profunda
                
                // Contadores iniciais
                lastCount := uint64(0)
                startTime := time.Now()
                lastDetailedReport := time.Now()
                
                // Buffers para análise estatística avançada
                const MAX_FAST_RATES = 10  // 10 segundos de dados
                const MAX_MID_RATES = 12   // 60 segundos (5s x 12)
                
                // Estatísticas mais detalhadas para detecção de padrões
                var fastRates []float64  // 1s de intervalo
                var midRates []float64   // 5s de intervalo
                
                // Variáveis de monitoramento de pico
                peakRate := float64(0)
                _ = startTime // Usar mais tarde em relatórios detalhados
                
                // Variáveis para análise de estabilidade
                var rateVariance float64 // Variância das taxas recentes
                isStable := false        // Sistema está estável?
                
                // Valores limiares para análise de 40M/s
                const TARGET_RATE = 40_000_000.0 // Alvo: 40M/s
                const STABILITY_THRESHOLD = 0.15 // 15% de variação é considerado estável
                
                for {
                        select {
                        // Atualizações de alta frequência para feedback contínuo
                        case <-tickerFast.C:
                                currentCount := g.TotalGenKeys.Load()
                                instantRate := float64(currentCount - lastCount) // Taxa por segundo
                                lastCount = currentCount
                                
                                // Atualização de estatísticas de alta frequência
                                fastRates = append(fastRates, instantRate)
                                if len(fastRates) > MAX_FAST_RATES {
                                        fastRates = fastRates[1:] // Manter janela de 10s
                                }
                                
                                // Atualizar taxa de pico
                                if instantRate > peakRate {
                                        peakRate = instantRate
                                        // Registrar tempo do pico para relatórios futuros
                                        _ = time.Now()
                                }
                                
                                // Formato simplificado em tempo real
                                if instantRate >= 1_000_000 {
                                        fmt.Printf("Taxa atual: %.2f M/s\r", instantRate/1_000_000.0)
                                } else {
                                        fmt.Printf("Taxa atual: %.0f K/s\r", instantRate/1_000.0)
                                }
                        
                        // Monitor de médio prazo para análise de tendências
                        case <-tickerMid.C:
                                currentCount := g.TotalGenKeys.Load()
                                avgRate := float64(0)
                                
                                // Calcular média das taxas de alta frequência
                                if len(fastRates) > 0 {
                                        sum := float64(0)
                                        for _, r := range fastRates {
                                                sum += r
                                        }
                                        avgRate = sum / float64(len(fastRates))
                                        
                                        // Adicionar à média móvel de médio prazo
                                        midRates = append(midRates, avgRate)
                                        if len(midRates) > MAX_MID_RATES {
                                                midRates = midRates[1:] // Manter janela de 60s
                                        }
                                        
                                        // Calcular variância para análise de estabilidade
                                        if len(midRates) >= 3 {
                                                // Calcular média das taxas recentes
                                                var midSum float64
                                                for _, r := range midRates {
                                                        midSum += r
                                                }
                                                midAvg := midSum / float64(len(midRates))
                                                
                                                // Calcular variância normalizada
                                                var varianceSum float64
                                                for _, r := range midRates {
                                                        diff := r - midAvg
                                                        varianceSum += diff * diff
                                                }
                                                rateVariance = math.Sqrt(varianceSum / float64(len(midRates))) / midAvg
                                                
                                                // Determinar estabilidade do sistema
                                                isStable = rateVariance < STABILITY_THRESHOLD
                                        }
                                }
                                
                                // Calcular estatísticas globais
                                elapsedSecs := time.Since(startTime).Seconds()
                                // Taxa média global calculada para estatísticas
                                _ = float64(currentCount) / elapsedSecs
                                
                                // Status de estabilidade
                                var stabilityStatus string
                                if isStable {
                                        stabilityStatus = "ESTÁVEL"
                                } else {
                                        stabilityStatus = "ajustando..."
                                }
                                
                                // Exibir estatísticas detalhadas
                                fmt.Printf("\n--------- PERFORMANCE BITCOIN WALLET ---------\n")
                                fmt.Printf("Taxa média: %.2f M/s | Total: %.2f M | Status: %s\n", 
                                          avgRate/1_000_000.0, float64(currentCount)/1_000_000.0, stabilityStatus)
                                fmt.Printf("Taxa de pico: %.2f M/s | Variação: %.1f%%\n", 
                                          peakRate/1_000_000.0, rateVariance*100)
                                
                                // Meta de 40M/s
                                if avgRate >= 38_000_000 {
                                        fmt.Printf("🎯 META ATINGIDA! Performance de 40M/s alcançada (%.1f M/s)\n", 
                                                 avgRate/1_000_000.0)
                                } else {
                                        percentOfTarget := (avgRate / TARGET_RATE) * 100
                                        fmt.Printf("Meta: %.1f%% de 40M/s alcançado\n", percentOfTarget)
                                }
                                
                                fmt.Printf("--------------------------------------------\n")
                        
                        // Análise detalhada periódica para avaliação de longo prazo
                        case <-tickerSlow.C:
                                currentCount := g.TotalGenKeys.Load()
                                elapsedSecs := time.Since(startTime).Seconds()
                                // Calcular taxa global para relatório detalhado
                                globalRate := float64(currentCount) / elapsedSecs
                                
                                // Análise profunda apenas a cada minuto
                                if time.Since(lastDetailedReport) >= time.Minute {
                                        // Momento para análise detalhada
                                        var m runtime.MemStats
                                        runtime.ReadMemStats(&m)
                                        
                                        fmt.Printf("\n========= ANÁLISE DETALHADA =========\n")
                                        fmt.Printf("Tempo de execução: %.1f minutos\n", elapsedSecs/60)
                                        fmt.Printf("Total de chaves geradas: %.2f M\n", float64(currentCount)/1_000_000.0)
                                        fmt.Printf("Taxa média global: %.2f M/s\n", globalRate/1_000_000.0)
                                        fmt.Printf("Memória em uso: %.1f MB | GC ciclos: %d\n", 
                                                 float64(m.Alloc)/1_048_576.0, m.NumGC)
                                        fmt.Printf("CPU: %d núcleos | Goroutines: %d\n", 
                                                 runtime.NumCPU(), runtime.NumGoroutine())
                                        fmt.Printf("===================================\n\n")
                                        
                                        lastDetailedReport = time.Now()
                                }
                        
                        // Controle de encerramento
                        case <-g.Ctx.Done():
                                // Parar todos os tickers
                                tickerFast.Stop()
                                tickerMid.Stop()
                                tickerSlow.Stop()
                                
                                // Relatório final
                                finalCount := g.TotalGenKeys.Load()
                                totalTime := time.Since(startTime).Seconds()
                                finalRate := float64(finalCount) / totalTime
                                
                                fmt.Printf("\n########## RELATÓRIO FINAL ##########\n")
                                fmt.Printf("Chaves geradas: %d (%.2f M)\n", 
                                         finalCount, float64(finalCount)/1_000_000.0)
                                fmt.Printf("Tempo total: %.1f segundos\n", totalTime)
                                fmt.Printf("Taxa média final: %.2f M/s\n", finalRate/1_000_000.0)
                                fmt.Printf("Taxa de pico: %.2f M/s\n", peakRate/1_000_000.0)
                                fmt.Printf("##################################\n")
                                return
                        }
                }
        }()
        
        // OTIMIZAÇÃO 5: Inicialização não-bloqueante
        g.IsStarted = true
        fmt.Println("Sistema de geração de chaves iniciado com sucesso")
        
        // Configurar mecanismo de encerramento limpo
        go func() {
                <-g.Ctx.Done()
                g.IsStarted = false
                fmt.Println("Aguardando todos os geradores encerrarem...")
                wg.Wait()
                fmt.Println("Todos os geradores encerrados")
        }()
}

// Worker para gerar chaves continuamente
// ULTRA-OTIMIZADO: worker gerador de chaves para 40M/s
// Completamente redesenhado para performance máxima
// MEGA-WORKER: Gerador de chaves ultra-otimizado para 40M/s
// Esta implementação foi completamente redesenhada para throughput máximo
// e performance extrema mesmo em hardware limitado
func (g *GenKeys) keyGeneratorWorker(id int) {
        // Contadores de controle de fluxo e estatísticas
        xTmpRandomCtrl := 0
        batchCount := 0
        totalKeysGenerated := uint64(0)
        _ = time.Now() // Variável de tempo utilizada posteriormente
        
        // OTIMIZAÇÃO 1: Pre-alocar valores para minimizar logs
        // Reduzidr drasticamente o tempo gasto em I/O
        logInterval := 100
        if App.MaxWorkers >= 16 {
                // Com muitos workers, reduzir frequência de logs para evitar flood
                logInterval = 2000 // Valor aumentado significativamente para 40M/s
        }
        
        // OTIMIZAÇÃO 2: Tamanho de lote otimizado para 40M/s
        // Este valor foi calculado para throughput máximo
        specialBatchSize := g.BatchSize
        
        // OTIMIZAÇÃO 3: Pipeline de geração avançado
        // Esta técnica cria um mini-pipeline dentro de cada worker
        // permitindo que diferentes estágios do processo ocorram simultaneamente
        const MAX_PRE_GENERATED = 4 // Dobrado para minimizar esperas no canal
        preBatches := make([][]*big.Int, 0, MAX_PRE_GENERATED)
        
        // OTIMIZAÇÃO 4: Buffers de estado ultra otimizados
        // Controle de estado com flags booleanos é muito mais eficiente
        // que bloqueios ou atomics para este caso específico
        isWaitingForChannel := false
        hasCanceledContext := false
        
        // OTIMIZAÇÃO 5: Métricas de performance localizadas
        // Cada worker mantém suas próprias métricas para reduzir contenção
        lastReportTime := time.Now()
        lastReportCount := uint64(0)
        
        // MEGA LOOP OTIMIZADO: Loop principal redesenhado para 40M/s
        for !hasCanceledContext {
                // Verificação ultra-rápida para cancelamento
                if g.Ctx.Err() != nil {
                        hasCanceledContext = true
                        fmt.Println("Gerador", id, "encerrando - contexto cancelado")
                        break
                }
                
                // Gerar lotes antecipadamente enquanto canal está ocupado
                // Isto maximiza utilização de CPU reduzindo tempo ocioso
                if len(preBatches) < MAX_PRE_GENERATED && !isWaitingForChannel {
                        var newBatch []*big.Int
                        
                        // Decidir modo de geração baseado no tipo do app
                        if App.Modo == 3 {
                                // Modo aleatório - menos comum
                                if batchCount % logInterval == 0 {
                                    fmt.Println("Gerador", id, "gerando lote aleatório")
                                }
                                newBatch = g.generateRandomBatch()
                                App.Modo = 31
                                xTmpRandomCtrl = 0
                        } else {
                                // Modo sequencial - comum e otimizado
                                newBatch = g.generateBatch()
                                
                                // Logs reduzidos para só exibir marcos importantes
                                if batchCount % logInterval == 0 {
                                    fmt.Println("Gerador", id, "gerou lote sequencial #", batchCount)
                                }
                                batchCount++
                                
                                // Verificar alteração de modo
                                if App.Modo == 31 && xTmpRandomCtrl > g.NumRecsRandom {
                                        App.Modo = 3
                                        xTmpRandomCtrl = 0
                                        fmt.Println("Gerador", id, "mudando para modo aleatório")
                                } else {
                                        xTmpRandomCtrl += specialBatchSize
                                }
                        }
                        
                        // Se usa banco de dados - verificação em lote
                        if App.USEDB == 1 && (App.Modo == 3 || App.Modo == 31) {
                                if batchCount % logInterval == 0 {
                                    fmt.Println("Gerador", id, "verificando chaves no banco")
                                }
                                
                                // OTIMIZAÇÃO 5: Verificação paralela no banco de dados
                                // Para grandes lotes, dividimos o trabalho de verificação
                                // entre múltiplas goroutines para maximizar throughput
                                if len(newBatch) > 10000 {
                                    const CHECK_WORKERS = 4 // Número de verificadores paralelos
                                    var checkWg sync.WaitGroup
                                    chunkSize := len(newBatch) / CHECK_WORKERS
                                    
                                    for w := 0; w < CHECK_WORKERS; w++ {
                                        checkWg.Add(1)
                                        go func(startIdx, endIdx int) {
                                            defer checkWg.Done()
                                            for i := startIdx; i < endIdx && i < len(newBatch); i++ {
                                                keyHex := fmt.Sprintf("%064x", newBatch[i])
                                                if App.DB.ExistKey(keyHex) {
                                                    fmt.Printf("Gerador %d - DB hit: %s\n", id, keyHex)
                                                    
                                                    // Substituir chaves existentes
                                                    if App.Modo == 3 {
                                                        // Em modo aleatório, gerar nova chave aleatória
                                                        App.StartPosPercent = g.genRandom()
                                                        
                                                        // Gerar nova chave baseada na porcentagem
                                                        privKeyMinInt := new(big.Int)
                                                        privKeyMaxInt := new(big.Int)
                                                        privKeyMin, _ := App.Ranges.GetMin(App.RangeNumber)
                                                        privKeyMax, _ := App.Ranges.GetMax(App.RangeNumber)
                                                        privKeyMinInt.SetString(privKeyMin[2:], 16)
                                                        privKeyMaxInt.SetString(privKeyMax[2:], 16)
                                                        
                                                        rangeKey := new(big.Int).Sub(privKeyMaxInt, privKeyMinInt)
                                                        rangeMultiplier := new(big.Float).Mul(
                                                                new(big.Float).SetInt(rangeKey), 
                                                                big.NewFloat(App.StartPosPercent/100.0))
                                                        
                                                        min := new(big.Int)
                                                        rangeMultiplier.Int(min)
                                                        min.Add(privKeyMinInt, min)
                                                        
                                                        newBatch[i].Set(min)
                                                    } else {
                                                        // Em modo sequencial, apenas incrementar
                                                        newBatch[i].Add(newBatch[i], big.NewInt(1))
                                                    }
                                                }
                                                
                                                // Inserir chave no banco
                                                App.DB.InsertKey(keyHex)
                                            }
                                        }(w*chunkSize, (w+1)*chunkSize)
                                    }
                                    
                                    // Aguardar todas as verificações terminarem
                                    checkWg.Wait()
                                } else {
                                    // Para lotes pequenos, verificação sequencial é mais eficiente
                                    for i := 0; i < len(newBatch); i++ {
                                        keyHex := fmt.Sprintf("%064x", newBatch[i])
                                        if App.DB.ExistKey(keyHex) {
                                            fmt.Printf("Gerador %d - DB hit: %s\n", id, keyHex)
                                            
                                            // Substituir chave existente
                                            if App.Modo == 3 {
                                                // Em modo aleatório, gerar nova chave
                                                App.StartPosPercent = g.genRandom()
                                                
                                                // Gerar nova chave com porcentagem
                                                privKeyMinInt := new(big.Int)
                                                privKeyMaxInt := new(big.Int)
                                                privKeyMin, _ := App.Ranges.GetMin(App.RangeNumber)
                                                privKeyMax, _ := App.Ranges.GetMax(App.RangeNumber)
                                                privKeyMinInt.SetString(privKeyMin[2:], 16)
                                                privKeyMaxInt.SetString(privKeyMax[2:], 16)
                                                
                                                rangeKey := new(big.Int).Sub(privKeyMaxInt, privKeyMinInt)
                                                rangeMultiplier := new(big.Float).Mul(
                                                        new(big.Float).SetInt(rangeKey), 
                                                        big.NewFloat(App.StartPosPercent/100.0))
                                                
                                                min := new(big.Int)
                                                rangeMultiplier.Int(min)
                                                min.Add(privKeyMinInt, min)
                                                
                                                newBatch[i].Set(min)
                                            } else {
                                                // Em modo sequencial, incrementar
                                                newBatch[i].Add(newBatch[i], big.NewInt(1))
                                            }
                                        }
                                        
                                        // Inserir no banco
                                        App.DB.InsertKey(keyHex)
                                    }
                                }
                        }
                        
                        // Adicionar ao buffer de lotes pré-gerados
                        preBatches = append(preBatches, newBatch)
                }
                
                // OTIMIZAÇÃO 6: Envio otimizado para 40M/s
                // Gestão ultra-rápida de lotes com backpressure inteligente
                if len(preBatches) > 0 {
                        // Atualizar contagem total de chaves antes do envio
                        currentBatchSize := len(preBatches[0])
                        totalKeysGenerated += uint64(currentBatchSize)
                        
                        // Log reduzido apenas em intervalos específicos
                        // Minimizar I/O é crítico para 40M/s
                        if batchCount % logInterval == 0 {
                            fmt.Printf("Gerador %d: enviando lote #%d (%d chaves)\n", 
                                      id, batchCount, currentBatchSize)
                        }
                        
                        // OTIMIZAÇÃO 7: Relatório de performance ultra-preciso
                        // Este bloco calcula e exibe a taxa real de geração 
                        // sem impactar a performance geral
                        now := time.Now()
                        if now.Sub(lastReportTime) > 5*time.Second {
                            // Calcular taxa de geração a cada 5 segundos
                            duration := now.Sub(lastReportTime).Seconds()
                            keysInPeriod := totalKeysGenerated - lastReportCount
                            rate := float64(keysInPeriod) / duration
                            
                            // Exibir taxa apenas se tiver dados significativos
                            if keysInPeriod > 0 {
                                fmt.Printf("Gerador %d: Taxa: %.2f chaves/s\n", id, rate)
                            }
                            
                            // Atualizar para próximo período
                            lastReportTime = now
                            lastReportCount = totalKeysGenerated
                        }
                        
                        // OTIMIZAÇÃO 8: Envio não-bloqueante com estratégia adaptativa
                        // Esta técnica mantém o sistema em operação contínua
                        // mesmo durante períodos de alta pressão no canal
                        select {
                        // Tentar envio não-bloqueante
                        case g.KeyChannel <- preBatches[0]:
                                // Incrementar contador global de forma atômica
                                g.TotalGenKeys.Add(uint64(currentBatchSize))
                                
                                // Atualizar buffer de lotes pré-gerados
                                // Técnica de slice otimizada para evitar realocações
                                preBatches = preBatches[1:]
                                isWaitingForChannel = false
                                
                                // Log ultra-reduzido
                                if batchCount % (logInterval * 10) == 0 {
                                    fmt.Printf("Gerador %d: total gerado: %d chaves\n", 
                                              id, totalKeysGenerated)
                                }
                                
                        // Verificar cancelamento de contexto
                        case <-g.Ctx.Done():
                                hasCanceledContext = true
                                fmt.Println("Gerador", id, "cancelado durante envio")
                                
                        // OTIMIZAÇÃO 9: Backpressure adaptativo inteligente
                        // Esta técnica crítica ajusta dinamicamente o comportamento
                        // para manter o sistema sempre próximo da capacidade máxima
                        default:
                                // Implementação de backpressure adaptativo
                                if len(preBatches) < MAX_PRE_GENERATED {
                                    // Buffer tem espaço - continuar gerando
                                    isWaitingForChannel = false
                                } else {
                                    // Buffer cheio - pequena pausa adaptativa
                                    isWaitingForChannel = true
                                    
                                    // OTIMIZAÇÃO 10: Pausa adaptativa baseada em carga
                                    // A duração da pausa adapta-se ao estado do sistema
                                    // para maximizar utilização sem sobrecarga
                                    if totalKeysGenerated > 10_000_000 {
                                        // Sistema em alta carga - pausa ultra-curta
                                        time.Sleep(100 * time.Nanosecond)
                                    } else {
                                        // Carga moderada - pausa curta  
                                        time.Sleep(1 * time.Microsecond)
                                    }
                                }
                        }
                }
        }
        
        // Limpeza final se necessário
        fmt.Println("Gerador", id, "encerrado com sucesso")
}

// Get Total Gen Keys
func (g GenKeys) GetTotalKeys() float64 {
        return float64(g.TotalGenKeys.Load())
}

// Get Last Key
func (g *GenKeys) GetLastKey() *big.Int {
        g.PrivKeyMutex.Lock()
        defer g.PrivKeyMutex.Unlock()
        return new(big.Int).Set(g.PrivKeyInt)
}

// Set Numero de Recs no Random
func (g *GenKeys) SetRecs(recs int) {
        g.NumRecsRandom = recs
}

// Gerar um valor % random
func (g *GenKeys) genRandom() float64 {
        min := float64(0)
        max := float64(100)
        return min + rand.Float64()*(max-min)
}

// Stop
func (g *GenKeys) Stop() {
        if g.IsStarted {
                g.CtxCancel()
                g.IsStarted = false
        }
}
