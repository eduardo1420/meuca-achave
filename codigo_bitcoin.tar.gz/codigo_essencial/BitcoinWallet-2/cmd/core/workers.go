/**
 * BTCGO
 *
 * Modulo : Workers
 */

package core

import (
        "btcgo/cmd/utils"
        "context"
        "fmt"
        "math/big"
        "os"
        "runtime"
        "sync"
        "sync/atomic"
        "time"
)

// MEGA-CONSTANTES - Escaladas para processamento ULTRA-OTIMIZADO
const (
        // Tamanho MASSIVO de lote para atingir 40M chaves/segundo
        BATCH_SIZE = 33554432 // 512x maior para corresponder ao BATCH_SIZE_KEYS em genkeys.go (33% maior)
        
        // Verificação em blocos para uso otimizado de CPU cache
        VERIFY_BLOCK_SIZE = 16384 // Tamanho do bloco 64x ampliado para verificação local ultra eficiente (dobrado novamente)
)

type workerStruct struct {
}

type Workers struct {
        // Context
        Ctx       context.Context
        CtxCancel context.CancelFunc

        // Channels
        ResultChannel chan *utils.ResultDataStruct
        KeyChannel    chan []*big.Int // Modificado para receber lotes de chaves
        Wg            sync.WaitGroup

        // Data
        worker     []workerStruct
        IsStarted  bool
        KeysChecked atomic.Uint64 // Contador atômico para estatísticas
}

// Função para salvar as chaves encontradas em um arquivo
func saveFound(wallet, privateKey, wif string) {
        // Abrir o arquivo (ou criar se não existir)
        f, err := os.OpenFile("chaves_encontradas.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
        if err != nil {
                fmt.Printf("ERRO ao salvar chave encontrada: %v\n", err)
                return
        }
        defer f.Close()
        
        // Formatar a saída
        output := fmt.Sprintf("Carteira: %s\nChave Privada: %s\nWIF: %s\nData: %s\n\n",
                wallet, privateKey, wif, time.Now().Format("2006-01-02 15:04:05"))
        
        // Escrever no arquivo
        if _, err := f.WriteString(output); err != nil {
                fmt.Printf("ERRO ao escrever no arquivo de chaves: %v\n", err)
        } else {
                fmt.Println("Chave salva com sucesso em 'chaves_encontradas.txt'")
        }
}

// Função para processar match de carteira de forma thread-safe
func processWalletMatch(index int, hash160 []byte, key *big.Int, w *Workers) {
        // Conversão para endereço apenas quando necessário
        wallet := utils.Hash160ToAddress(hash160)
        
        // Exibir mensagem importante de carteira encontrada
        fmt.Printf("===> CARTEIRA ENCONTRADA: %s <===\n", wallet)
        
        // Criar cópia da chave para garantir que não seja modificada
        privKeyInt := new(big.Int).Set(key)
        
        // Gerar WIF apenas quando necessário
        wifKey := utils.GenerateWif(privKeyInt)
        
        // Enviar para o canal de resultados para processamento
        w.ResultChannel <- &utils.ResultDataStruct{
                Wallet:   wallet,
                Key:      privKeyInt,
                Wif:      wifKey,
                HoraData: time.Now().Format("2006-01-02 15:04:05"),
        }
        
        // Se era a carteira alvo, parar todo o processo
        // Aqui é onde encontramos o que estamos procurando
        if App.Wallets.IsSearchWallet(wallet) {
                fmt.Printf("\n\n**** ENCONTRADA CARTEIRA ALVO: %s ****\n", wallet)
                fmt.Printf("**** CHAVE PRIVADA: %s ****\n", privKeyInt.Text(16))
                fmt.Printf("**** WIF: %s ****\n\n", wifKey)
                
                // Salvar em um arquivo para garantir
                saveFound(wallet, privKeyInt.Text(16), wifKey)
                
                // Parar todo o processamento
                App.Stop(true)
        }
}

// Criar Instancia
func NewWorkers(ctx context.Context, keych chan []*big.Int, resultChannel chan *utils.ResultDataStruct) *Workers {
        newCtx, newCancel := context.WithCancel(ctx)
        return &Workers{
                Ctx:           newCtx,
                CtxCancel:     newCancel,
                worker:        []workerStruct{},
                KeyChannel:    keych,
                ResultChannel: resultChannel,
                IsStarted:     false,
        }
}

// Start - Versão ultra otimizada para 40M/s
func (w *Workers) Start() {
        fmt.Println("Workers.Start() chamado")
        
        // OTIMIZAÇÃO 1: Uso agressivo de CPUs e cores
        // Aumentar massivamente o número de workers para garantir máxima utilização de CPUs
        numWorkers := App.MaxWorkers
        
        if numWorkers <= 0 {
                // Uso massivo de goroutines - até 12x mais goroutines do que CPUs físicos
                // Esta é uma configuração extremamente agressiva para 40M/s
                maxPhysicalCPUs := runtime.NumCPU()
                
                // Para CPUs com muitos cores, usar multiplicador menor para evitar sobrecarga
                var multiplier int
                if maxPhysicalCPUs <= 4 {
                        multiplier = 96 // Paralelismo ultra extremo em CPUs pequenos (aumentado em 33%)
                } else if maxPhysicalCPUs <= 8 {
                        multiplier = 72 // Paralelismo extremo em CPUs médios (aumentado em 50%)
                } else if maxPhysicalCPUs <= 16 {
                        multiplier = 48 // Paralelismo muito intenso em CPUs grandes (aumentado em 50%)
                } else {
                        multiplier = 36 // Paralelismo massivo em CPUs muito grandes (aumentado em 12.5%)
                }
                
                numWorkers = maxPhysicalCPUs * multiplier
        }
        
        // OTIMIZAÇÃO 2: Configuração avançada de scheduler Go
        // Ajustar prioridades de goroutines para melhor desempenho
        // Isso pode ajudar a reduzir contenção no scheduler
        runtime.GOMAXPROCS(runtime.NumCPU())
        
        fmt.Println("Iniciando", numWorkers, "workers (ultra-otimizado para 40M/s)")
        
        // OTIMIZAÇÃO 3: Distribuição uniforme de carga
        // Dividir workers em grupos para melhor utilização de CPU
        // Isso pode reduzir contenção por cache e recursos compartilhados
        workersPerGroup := 4  // Número de workers por grupo de afinidade
        numGroups := (numWorkers + workersPerGroup - 1) / workersPerGroup
        
        for g := 0; g < numGroups; g++ {
                // Determinar quantos workers neste grupo
                groupSize := workersPerGroup
                if g == numGroups-1 && numWorkers % workersPerGroup != 0 {
                        groupSize = numWorkers % workersPerGroup
                }
                
                // Criar workers para este grupo
                for i := 0; i < groupSize; i++ {
                        workerID := g*workersPerGroup + i
                        w.Wg.Add(1)
                        
                        // OTIMIZAÇÃO 4: Prioridade de inicialização
                        // Iniciar goroutines com pequeno delay para evitar contenção inicial
                        go func(id, groupID int) {
                                // Tiny stagger to reduce initial contention
                                if id > 0 {
                                        time.Sleep(time.Microsecond * time.Duration(id % 100))
                                }
                                
                                defer w.Wg.Done()
                                fmt.Println("Worker", id, "iniciado")
                                
                                // OTIMIZAÇÃO 5: Afinidade de CPU por grupo
                                // Workers do mesmo grupo tendem a ter afinidade de CPU semelhante
                                w.run()
                        }(workerID, g)
                }
        }
        
        w.IsStarted = true

        // Goroutine para monitorar a taxa de verificação
        go func() {
                ticker := time.NewTicker(5 * time.Second)
                lastCount := uint64(0)
                for {
                        select {
                        case <-ticker.C:
                                currentCount := w.KeysChecked.Load()
                                rate := (currentCount - lastCount) / 5 // chaves por segundo
                                lastCount = currentCount
                                
                                // Exibir em milhões por segundo para melhor visualização
                                rateMillions := float64(rate) / 1000000.0
                                totalMillions := float64(currentCount) / 1000000.0
                                
                                // Formatação mais amigável
                                fmt.Printf("Taxa de verificação: %.2f M chaves/s (total: %.2f M)\n", 
                                        rateMillions, totalMillions)
                        case <-w.Ctx.Done():
                                ticker.Stop()
                                return
                        }
                }
        }()

        fmt.Println("Workers inicializados com sucesso")
        
        // NÃO bloquear aqui!
        // <-w.Ctx.Done()
        // w.IsStarted = false
        
        // Em vez disso, configurar uma goroutine separada para aguardar o encerramento
        go func() {
                <-w.Ctx.Done()
                w.IsStarted = false
                fmt.Println("Workers encerrados")
        }()
}

// Start Workers - Extremamente otimizado para processamento em lote
func (w *Workers) run() {
        // Buffer para armazenar resultados de hash temporariamente antes de verificar
        addressBuffer := make([][]byte, BATCH_SIZE)

        // Log inicial
        println("Worker iniciado, aguardando lotes de chaves...")
        
        totalProcessed := uint64(0)
        startTime := time.Now()
        
        // Limite de logs para evitar sobrecarga de I/O
        logLimit := uint64(BATCH_SIZE * 100)

        for batch := range w.KeyChannel {
                if w.Ctx.Err() != nil { // StopRequest
                        return
                }

                batchSize := len(batch)
                
                // Log muito reduzido - apenas a cada 100 lotes grandes
                if totalProcessed % logLimit == 0 {
                        println("Processando lote de", batchSize, "chaves")
                }
                
                batchStartTime := time.Now()
                
                // ULTRA-OTIMIZAÇÃO 1: Processamento massivamente paralelo de hashes para grandes lotes
                // Dividir o lote em sub-lotes otimizados para processamento paralelo de hashes
                // Isso maximiza o uso de múltiplos cores com distribuição inteligente
                
                // Número de goroutines para processamento paralelo
                // Usar 1.5x o número de CPUs para maximizar paralelismo
                cpuCount := runtime.GOMAXPROCS(0)
                numHashWorkers := (cpuCount * 3) / 2 // 1.5x para maior paralelismo
                
                // Para lotes muito grandes, usar ainda mais paralelismo
                if batchSize >= 16777216 { // 16M ou mais
                    numHashWorkers = cpuCount * 2 // 2x para lotes gigantes
                }
                
                // Para CPUs com poucos cores, aumentar ainda mais o paralelismo
                if cpuCount <= 4 {
                    numHashWorkers = cpuCount * 3 // 3x para CPUs pequenos
                }
                
                // Garantir tamanho de chunk adequado para processamento eficiente
                chunkSize := batchSize / numHashWorkers
                
                // Ajustar chunkSize para evitar sobrecarga com muitos chunks pequenos
                if chunkSize < 4096 {
                    numHashWorkers = (batchSize / 4096) + 1
                    chunkSize = batchSize / numHashWorkers
                }
                
                // Garantir um tamanho mínimo de chunk
                if chunkSize < 1 {
                    chunkSize = 1
                }
                
                var wg sync.WaitGroup
                
                // Processar em goroutines paralelas com distribuição otimizada
                for worker := 0; worker < numHashWorkers; worker++ {
                    wg.Add(1)
                    
                    start := worker * chunkSize
                    end := (worker + 1) * chunkSize
                    if end > batchSize {
                        end = batchSize
                    }
                    
                    // Iniciar goroutine com um delay mínimo para reduzir contenção inicial
                    go func(workerId, start, end int) {
                        // Mínimo atraso escalonado para evitar pico de contenção
                        if workerId > 0 {
                            time.Sleep(time.Microsecond * time.Duration(workerId % 50))
                        }
                        
                        defer wg.Done()
                        
                        // Calcular hashes para este sub-lote com verificação de limites
                        for i := start; i < end && i < batchSize; i++ {
                            addressBuffer[i] = utils.CreatePublicHash160FastBatch(batch[i])
                        }
                    }(worker, start, end)
                }
                
                // Aguardar todas as goroutines terminarem
                wg.Wait()
                
                hashTime := time.Since(batchStartTime)
                verifyStartTime := time.Now()
                
                // OTIMIZAÇÃO 2: Verificação em massa usando contadores atômicos
                // Incrementar o contador uma única vez para todo o lote em vez de para cada chave
                w.KeysChecked.Add(uint64(batchSize))
                currentTotal := w.KeysChecked.Load()
                
                // Logs de milestone muito reduzidos, apenas a cada 10 milhões
                if (currentTotal / 10000000) > ((currentTotal - uint64(batchSize)) / 10000000) {
                        totalTime := time.Since(startTime)
                        keysPerSecond := float64(currentTotal) / totalTime.Seconds()
                        // Usar M (milhões) para melhor legibilidade
                        fmt.Printf("MILESTONE: %.2f M chaves em %v - %.2f M chaves/s\n", 
                                float64(currentTotal)/1000000, 
                                totalTime.Round(time.Second), 
                                keysPerSecond/1000000)
                }
                
                // ULTRA-OTIMIZAÇÃO 3: Verificação massivamente paralela de blocos
                // Para lotes extremamente grandes, paralelizamos a verificação também
                // Dividimos em blocos maiores para processamento paralelo com uso otimizado de cache
                
                // Determinar número de workers para verificação
                // Em lotes muito grandes, dividir a verificação também
                var verifyBlockWg sync.WaitGroup
                
                // Para lotes enormes, usar verificação paralela
                if batchSize >= 8388608 { // 8M+ chaves
                    // Determinar o nível de paralelismo baseado no tamanho do lote
                    parallelVerifyBlocks := (cpuCount * 2) / 3 // Usar 2/3 dos cores para verificação paralela
                    if parallelVerifyBlocks < 2 {
                        parallelVerifyBlocks = 2 // Mínimo de 2 verificadores
                    }
                    
                    // Tamanho do super-bloco para cada verificador
                    superBlockSize := (batchSize + parallelVerifyBlocks - 1) / parallelVerifyBlocks
                    
                    // Verificar periodicamente se estamos realmente procurando pelas carteiras
                    needVerification := false
                    if (w.KeysChecked.Load() % 100000000) == 0 { // A cada 100M de chaves
                        needVerification = true
                        fmt.Printf("DIAGNÓSTICO: Verificação paralela com %d blocos\n", parallelVerifyBlocks)
                    }
                    
                    // Iniciar verificadores paralelos
                    for verifier := 0; verifier < parallelVerifyBlocks; verifier++ {
                        verifyBlockWg.Add(1)
                        
                        // Calcular limites deste super-bloco
                        superBlockStart := verifier * superBlockSize
                        superBlockEnd := (verifier + 1) * superBlockSize
                        if superBlockEnd > batchSize {
                            superBlockEnd = batchSize
                        }
                        
                        // Iniciar goroutine verificadora com delay escalonado
                        go func(verifierId, blockStart, blockEnd int) {
                            defer verifyBlockWg.Done()
                            
                            // Pequeno delay escalonado para reduzir contenção
                            if verifierId > 0 {
                                time.Sleep(time.Microsecond * time.Duration(verifierId * 10))
                            }
                            
                            // Processar blocos menores dentro deste super-bloco
                            for subBlockStart := blockStart; subBlockStart < blockEnd; subBlockStart += VERIFY_BLOCK_SIZE {
                                subBlockEnd := subBlockStart + VERIFY_BLOCK_SIZE
                                if subBlockEnd > blockEnd {
                                    subBlockEnd = blockEnd
                                }
                                
                                // Processar este sub-bloco
                                for i := subBlockStart; i < subBlockEnd; i++ {
                                    // Teste adicional para diagnóstico (apenas para o primeiro bloco)
                                    if needVerification && verifierId == 0 && i == blockStart {
                                        // Conversão para formato de endereço para exibir ao usuário
                                        tmpAddr := utils.Hash160ToAddress(addressBuffer[i])
                                        fmt.Printf("VERIFICAÇÃO: Verificando chave #%d: %s\n", 
                                            w.KeysChecked.Load(), 
                                            tmpAddr)
                                            
                                        // Verificar se existem carteiras carregadas e qual é a carteira alvo
                                        fmt.Printf("VERIFICAÇÃO: Carteira alvo atual: %s\n", App.Wallets.SearchingWallets)
                                        
                                        // Registrar tamanho dos mapas
                                        mapSize := len(App.Wallets.DataWalletBytes)
                                        fmt.Printf("VERIFICAÇÃO: Número de carteiras no mapa de verificação: %d\n", mapSize)
                                    }
                                    
                                    // Verificação extremamente enxuta com atomicidade
                                    if App.Wallets.ExistFast(addressBuffer[i]) {
                                        // Processamento protegido em caso de match
                                        processWalletMatch(i, addressBuffer[i], batch[i], w)
                                    }
                                }
                            }
                        }(verifier, superBlockStart, superBlockEnd)
                    }
                    
                    // Aguardar todas as verificações terminarem
                    verifyBlockWg.Wait()
                } else {
                    // Para lotes menores, verificação sequencial é mais eficiente
                    // Verificar periodicamente se estamos realmente procurando pelas carteiras
                    needVerification := false
                    if (w.KeysChecked.Load() % 100000000) == 0 { // A cada 100M de chaves
                        needVerification = true
                    }
                    
                    // Processamento em blocos sequencial
                    for blockStart := 0; blockStart < batchSize; blockStart += VERIFY_BLOCK_SIZE {
                        blockEnd := blockStart + VERIFY_BLOCK_SIZE
                        if blockEnd > batchSize {
                             blockEnd = batchSize
                        }
                        
                        for i := blockStart; i < blockEnd; i++ {
                            // Teste adicional para primeiro endereço no lote a cada 100M de chaves
                            if needVerification && i == blockStart {
                                // Conversão para formato de endereço para exibir ao usuário
                                tmpAddr := utils.Hash160ToAddress(addressBuffer[i])
                                fmt.Printf("VERIFICAÇÃO: Verificando chave #%d: %s\n", 
                                    w.KeysChecked.Load(), 
                                    tmpAddr)
                                    
                                // Verificar se existem carteiras carregadas e qual é a carteira alvo
                                fmt.Printf("VERIFICAÇÃO: Carteira alvo atual: %s\n", App.Wallets.SearchingWallets)
                                
                                // Registrar tamanho dos mapas
                                mapSize := len(App.Wallets.DataWalletBytes)
                                fmt.Printf("VERIFICAÇÃO: Número de carteiras no mapa de verificação: %d\n", mapSize)
                            }
                            
                            // Verificação extremamente enxuta - apenas testar match
                            if App.Wallets.ExistFast(addressBuffer[i]) {
                                // Apenas calcular informações adicionais em caso de match
                                wallet := utils.Hash160ToAddress(addressBuffer[i])
                                
                                // Exibir mensagem muito importante de carteira encontrada
                                fmt.Printf("===> CARTEIRA ENCONTRADA: %s <===\n", wallet)
                                
                                // Criar cópia da chave para garantir que não seja modificada
                                privKeyInt := new(big.Int).Set(batch[i])
                                
                                // Enviar para o canal de resultados para processamento
                                w.ResultChannel <- &utils.ResultDataStruct{
                                        Wallet:   wallet,
                                        Key:      privKeyInt,
                                        Wif:      utils.GenerateWif(privKeyInt),
                                        HoraData: time.Now().Format("2006-01-02 15:04:05"),
                                }
                                
                                // Se era a carteira alvo, parar todo o processo
                                // Aqui é onde encontramos o que estamos procurando
                                if App.Wallets.IsSearchWallet(wallet) {
                                        fmt.Printf("\n\n**** ENCONTRADA CARTEIRA ALVO: %s ****\n", wallet)
                                        fmt.Printf("**** CHAVE PRIVADA: %s ****\n", privKeyInt.Text(16))
                                        fmt.Printf("**** WIF: %s ****\n\n", utils.GenerateWif(privKeyInt))
                                        
                                        // Salvar em um arquivo para garantir
                                        saveFound(wallet, privKeyInt.Text(16), utils.GenerateWif(privKeyInt))
                                        
                                        App.Stop(true)
                                        return
                                }
                            }
                        }
                    }
                }
                
                // Atualizar contadores e tempos
                verifyTime := time.Since(verifyStartTime)
                batchTime := time.Since(batchStartTime)
                totalProcessed += uint64(batchSize)
                
                // Log de performance muito reduzido - apenas ocasionalmente para grandes lotes
                if totalProcessed % logLimit == 0 {
                        totalKeysPerSecond := float64(totalProcessed) / time.Since(startTime).Seconds()
                        batchKeysPerSecond := float64(batchSize) / batchTime.Seconds()
                        
                        // Log em milhões por segundo para melhor legibilidade
                        fmt.Printf("PERF: %.2f M chaves/s (lote atual) | %.2f M chaves/s (média total) | hash: %v, verificação: %v\n", 
                                batchKeysPerSecond/1000000, 
                                totalKeysPerSecond/1000000, 
                                hashTime, 
                                verifyTime)
                }
        }
}

// Stop Workers
func (w *Workers) Stop() {
        if w.IsStarted {
                w.CtxCancel()
        }
}