#!/bin/bash

# Verificar se o Bitcoin Wallet já existe, senão mostrar mensagem
if [ ! -f "BitcoinWallet-2/bitcoinwallet" ]; then
    echo "ERRO: O executável 'bitcoinwallet' não foi encontrado!"
    echo "Por favor, certifique-se de que o arquivo BitcoinWallet-2/bitcoinwallet existe e tem permissão de execução."
    exit 1
fi

# Definir função para exibir o menu
show_menu() {
    clear
    echo "================================="
    echo "    BITCOIN WALLET INTERFACE     "
    echo "================================="
    echo ""
    echo "Selecione a opção desejada:"
    echo ""
    echo "1. Iniciar interface interativa (Modo Console)"
    echo "2. Iniciar em Modo 1 (Do início)"
    echo "3. Iniciar em Modo 2 (Sequencial)"
    echo "4. Iniciar em Modo 3 (Random/Aleatório)"
    echo "5. Exibir ajuda"
    echo "6. Verificar chaves encontradas"
    echo "7. Sair"
    echo ""
    echo -n "Digite sua escolha (1-7): "
    read choice

    case $choice in
        1)
            echo "Iniciando interface interativa..."
            echo "Pressione Ctrl+C para interromper."
            ./run_interface.sh
            ;;
        2)
            echo "Iniciando em Modo 1 (do início)..."
            read -p "Número de CPUs (padrão: 4): " cpu
            cpu=${cpu:-4}
            read -p "Número da carteira (1-161, padrão: 1): " wallet
            wallet=${wallet:-1}
            
            cd BitcoinWallet-2 && ./bitcoinwallet -cpu $cpu -carteira $wallet -modo 1
            ;;
        3)
            echo "Iniciando em Modo 2 (Sequencial)..."
            read -p "Número de CPUs (padrão: 4): " cpu
            cpu=${cpu:-4}
            read -p "Número da carteira (1-161, padrão: 1): " wallet
            wallet=${wallet:-1}
            read -p "Tipo de sequencial (1=do início, 2=do range, padrão: 1): " seq_type
            seq_type=${seq_type:-1}
            read -p "Percentual do range (padrão: 50): " percent
            percent=${percent:-50}
            
            cd BitcoinWallet-2 && ./bitcoinwallet -cpu $cpu -carteira $wallet -modo 2 -sequencial $seq_type -percentual $percent
            ;;
        4)
            echo "Iniciando em Modo 3 (Random/Aleatório)..."
            read -p "Número de CPUs (padrão: 4): " cpu
            cpu=${cpu:-4}
            read -p "Número da carteira (1-161, padrão: 1): " wallet
            wallet=${wallet:-1}
            read -p "Usar DB (1=usar DB, 2=sem DB, padrão: 1): " usedb
            usedb=${usedb:-1}
            read -p "Número de registros (padrão: 10000): " numrecs
            numrecs=${numrecs:-10000}
            
            cd BitcoinWallet-2 && ./bitcoinwallet -cpu $cpu -carteira $wallet -modo 3 -usedb $usedb -numrecs $numrecs
            ;;
        5)
            cd BitcoinWallet-2 && ./bitcoinwallet -help
            echo ""
            echo "Pressione Enter para voltar ao menu principal..."
            read
            show_menu
            ;;
        6)
            check_found_keys
            ;;
        7)
            echo "Saindo..."
            exit 0
            ;;
        *)
            echo "Opção inválida. Pressione Enter para continuar..."
            read
            show_menu
            ;;
    esac
}

# Função para verificar chaves encontradas
check_found_keys() {
    if [ -f "BitcoinWallet-2/chaves_encontradas.txt" ]; then
        clear
        echo "==========================================="
        echo "    CHAVES ENCONTRADAS                     "
        echo "==========================================="
        echo ""
        cat BitcoinWallet-2/chaves_encontradas.txt
        echo ""
        echo "==========================================="
    else
        echo "Nenhuma chave encontrada ainda."
    fi
    
    echo ""
    echo "Pressione Enter para voltar ao menu principal..."
    read
    show_menu
}

# Verificar se o Python está instalado
if ! command -v python &> /dev/null; then
    echo "ERRO: Python não encontrado!"
    echo "Este script requer Python para funcionar corretamente."
    exit 1
fi

# Verificar se o servidor web já está rodando
SERVER_RUNNING=0
if pgrep -f "python server.py" > /dev/null; then
    SERVER_RUNNING=1
    echo "Servidor web já está rodando."
else
    # Iniciar o servidor web em segundo plano
    nohup python server.py > /dev/null 2>&1 &
    SERVER_PID=$!
    
    # Esperar um momento para o servidor iniciar
    sleep 2
    
    if ! ps -p $SERVER_PID > /dev/null; then
        echo "AVISO: Não foi possível iniciar o servidor web."
    else
        echo "Servidor web iniciado com sucesso."
        echo "Verifique a aba 'Webview' para instruções detalhadas."
    fi
fi

# Mensagem para o usuário
echo ""
echo "==================================================="
echo "   Bitcoin Wallet - Interface Web e Linha de Comando"
echo "==================================================="
echo ""
echo "INTERFACE WEB INICIADA"
echo "Acesse a interface Web na aba 'Webview' do Replit"
echo ""
echo "Para iniciar a aplicação, use o menu abaixo ou"
echo "abra um novo terminal e execute: ./run_interface.sh"
echo "==================================================="
echo ""

# Mostra o menu e inicia a interação
show_menu

# Ao sair do menu, encerrar o servidor web se foi iniciado por este script
if [ "$SERVER_RUNNING" -eq 0 ] && [ -n "$SERVER_PID" ]; then
    echo "Encerrando servidor web..."
    kill $SERVER_PID 2>/dev/null || true
fi

echo "Aplicação encerrada."
exit 0