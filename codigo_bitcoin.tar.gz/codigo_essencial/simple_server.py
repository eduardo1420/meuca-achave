#!/usr/bin/env python3
import http.server
import socketserver
import os
import sys
import time
import datetime
import traceback

# Configuração simples
PORT = 8080
log_file = "server_webview.log"
start_time = datetime.datetime.now()

# Função para log
def log_message(message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}"
    print(log_entry)
    try:
        with open(log_file, "a") as f:
            f.write(log_entry + "\n")
    except Exception as e:
        print(f"Erro ao escrever no log: {str(e)}")
    sys.stdout.flush()

# Criar arquivo HTML
def create_html_file():
    try:
        # Verificar se existem chaves encontradas
        found_keys_count = 0
        try:
            if os.path.exists("BitcoinWallet-2/chaves_encontradas.txt"):
                with open("BitcoinWallet-2/chaves_encontradas.txt", "r") as f:
                    found_keys_count = sum(1 for line in f if line.strip())
        except:
            pass
        
        found_keys_html = ""
        if found_keys_count > 0:
            found_keys_html = f"""
            <div class="results">
                <strong>Chaves Encontradas:</strong> {found_keys_count} chaves descobertas até o momento.
                <p>Para visualizar as chaves, execute: <code>./show_found_keys.sh</code></p>
            </div>
            """

        html_content = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="60">
    <title>Bitcoin Wallet - Interface</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }}
        h1 {{
            color: #f7931a;
            border-bottom: 2px solid #f7931a;
            padding-bottom: 10px;
        }}
        .instructions {{
            background-color: #f8f9fa;
            border-left: 4px solid #f7931a;
            padding: 15px;
            margin: 20px 0;
        }}
        .code {{
            background-color: #272822;
            color: #f8f8f2;
            font-family: monospace;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
        }}
        .warning {{
            background-color: #fff3cd;
            color: #856404;
            padding: 15px;
            border-left: 4px solid #ffeeba;
            margin: 20px 0;
        }}
        .step {{
            margin-bottom: 20px;
        }}
        .step-number {{
            display: inline-block;
            background-color: #f7931a;
            color: white;
            width: 25px;
            height: 25px;
            text-align: center;
            border-radius: 50%;
            margin-right: 10px;
        }}
        .button {{
            display: inline-block;
            background-color: #f7931a;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 20px;
        }}
        .button:hover {{
            background-color: #e67e00;
        }}
        .scripts {{
            margin-top: 30px;
            padding: 15px;
            background-color: #e9ecef;
            border-radius: 4px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }}
        th, td {{
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }}
        th {{
            background-color: #f7931a;
            color: white;
        }}
        tr:hover {{
            background-color: #f1f1f1;
        }}
        .results {{
            background-color: #d1e7dd;
            color: #0f5132;
            padding: 15px;
            border-left: 4px solid #badbcc;
            margin: 20px 0;
        }}
        .server-info {{
            background-color: #cfe2ff;
            color: #084298;
            padding: 15px;
            border-left: 4px solid #b6d4fe;
            margin: 20px 0;
        }}
        .timestamp {{
            font-size: 0.8em;
            color: #6c757d;
            text-align: right;
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <h1>Bitcoin Wallet - Interface</h1>
    
    <div class="server-info">
        <strong>Status do Servidor:</strong> Ativo desde {start_time.strftime("%Y-%m-%d %H:%M:%S")}
        <p>Esta página atualiza automaticamente a cada 60 segundos.</p>
    </div>
    
    {found_keys_html}
    
    <div class="warning">
        <strong>Nota:</strong> Esta aplicação funciona apenas no terminal. Siga as instruções abaixo para executá-la.
    </div>
    
    <h2>Scripts Disponíveis</h2>
    
    <table>
        <tr>
            <th>Script</th>
            <th>Descrição</th>
        </tr>
        <tr>
            <td><code>./start.sh</code></td>
            <td><strong>Script principal de inicialização</strong> - Execute este script primeiro</td>
        </tr>
        <tr>
            <td><code>./run.sh</code></td>
            <td>Menu principal de execução com todas as opções</td>
        </tr>
        <tr>
            <td><code>./run_interface.sh</code></td>
            <td>Interface interativa com menu de opções para cada modo</td>
        </tr>
        <tr>
            <td><code>./show_found_keys.sh</code></td>
            <td>Visualiza as chaves encontradas em formato legível</td>
        </tr>
        <tr>
            <td><code>./restart_server.sh</code></td>
            <td>Reinicia o servidor web se ele parar de funcionar</td>
        </tr>
        <tr>
            <td><code>./check_server.sh</code></td>
            <td>Verifica o status do servidor web e mostra logs recentes</td>
        </tr>
    </table>
    
    <h2>Instruções de Uso</h2>
    
    <div class="instructions">
        <div class="step">
            <span class="step-number">1</span>
            <strong>Abra o console do Replit:</strong> Clique no botão "Shell" na barra lateral ou pressione <code>Ctrl+Shift+S</code>.
        </div>
        
        <div class="step">
            <span class="step-number">2</span>
            <strong>Execute a interface:</strong> Digite o seguinte comando e pressione Enter:
            <div class="code">./run.sh</div>
            ou
            <div class="code">./run_interface.sh</div>
        </div>
        
        <div class="step">
            <span class="step-number">3</span>
            <strong>Utilize a interface:</strong> Siga as instruções na tela para selecionar o modo de operação e configurar os parâmetros.
        </div>
    </div>
    
    <h2>Modos de Operação</h2>
    
    <ol>
        <li><strong>Modo 1 - Do início:</strong> Inicia a busca do começo do range.</li>
        <li><strong>Modo 2 - Sequencial:</strong> Permite escolher um ponto específico para iniciar a busca.</li>
        <li><strong>Modo 3 - Random (Aleatório):</strong> Gera chaves aleatórias dentro do range.</li>
    </ol>
    
    <h2>Parâmetros Comuns</h2>
    
    <ul>
        <li><strong>CPUs:</strong> Número de processadores a serem utilizados.</li>
        <li><strong>Carteira:</strong> Número da carteira a ser verificada (1-161).</li>
    </ul>
    
    <h2>Visualizando Resultados</h2>
    
    <div class="results">
        <p>Para visualizar as chaves encontradas, execute:</p>
        <div class="code">./show_found_keys.sh</div>
        <p>As chaves encontradas são salvas em <code>BitcoinWallet-2/chaves_encontradas.txt</code>.</p>
    </div>
    
    <div class="warning">
        <strong>Importante:</strong> Para interromper a execução a qualquer momento, pressione <code>Ctrl+C</code>.
    </div>
    
    <a href="https://replit.com/console" class="button">Abrir Console</a>
    
    <div class="timestamp">
        Última atualização: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    </div>
</body>
</html>
"""
        with open("index.html", "w") as f:
            f.write(html_content)
        log_message("Arquivo HTML criado com sucesso.")
        return True
    except Exception as e:
        log_message(f"ERRO ao criar HTML: {str(e)}")
        log_message(traceback.format_exc())
        return False

# Manipulador HTTP personalizado para registrar acessos
class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        log_message(f"[Acesso Web] {args[0]} {args[1]} {args[2]}")
    
    def end_headers(self):
        # Adicionar cabeçalhos para atualização e cache
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

# Principal
if __name__ == "__main__":
    # Criar arquivo de log
    with open(log_file, "w") as f:
        f.write(f"[{start_time.strftime('%Y-%m-%d %H:%M:%S')}] Iniciando servidor...\n")
    
    # Registrar PID
    try:
        pid = os.getpid()
        with open(".server_pid", "w") as f:
            f.write(str(pid))
        log_message(f"PID {pid} registrado no arquivo .server_pid")
    except Exception as e:
        log_message(f"Erro ao registrar PID: {str(e)}")
    
    try:
        # Criar arquivo HTML
        if not create_html_file():
            log_message("Falha ao criar o arquivo HTML. Tentando novamente...")
            time.sleep(1)
            create_html_file()
        
        # Configurar e iniciar o servidor
        log_message("Configurando servidor web...")
        Handler = CustomHTTPRequestHandler
        
        # Loop para tentar iniciar o servidor
        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
                    log_message(f"Servidor iniciado na porta {PORT}")
                    log_message(f"Acesse: http://0.0.0.0:{PORT} ou use a aba Webview no Replit")
                    log_message("IMPORTANTE: Para executar a aplicação Bitcoin Wallet use ./run.sh")
                    httpd.serve_forever()
            except Exception as e:
                log_message(f"Tentativa {attempt}/{max_attempts} falhou: {str(e)}")
                if attempt < max_attempts:
                    log_message(f"Tentando novamente em 3 segundos...")
                    time.sleep(3)
                else:
                    log_message(f"Todas as tentativas falharam. Verifique se a porta {PORT} já está em uso.")
                    raise
    except Exception as e:
        log_message(f"Erro fatal: {str(e)}")
        log_message(traceback.format_exc())
    finally:
        log_message("Servidor encerrado.")