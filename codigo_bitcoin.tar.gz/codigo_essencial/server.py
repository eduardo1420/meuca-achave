import http.server
import socketserver
import os
import sys
import time
import threading
import signal
import socket

# Configuração do servidor
PORT = 8080
HOST = "0.0.0.0"

# Função para registrar mensagens de log
def log_message(message):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}")
    sys.stdout.flush()

# Classe de handler personalizada
class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        log_message(f"{self.client_address[0]} - {format % args}")
    
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

# Função principal para iniciar o servidor
def start_server():
    try:
        with socketserver.TCPServer((HOST, PORT), CustomHTTPRequestHandler) as httpd:
            log_message(f"Servidor iniciado em http://{HOST}:{PORT}")
            log_message(f"Pressione Ctrl+C para parar o servidor")
            
            # Iniciar o servidor
            httpd.serve_forever()
    except OSError as e:
        if e.errno == 98:  # Endereço já em uso
            log_message(f"ERRO: A porta {PORT} já está em uso. Tente fechar outros servidores ou usar outra porta.")
        else:
            log_message(f"ERRO ao iniciar o servidor: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        log_message("Servidor encerrado pelo usuário")
    except Exception as e:
        log_message(f"ERRO inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Iniciar o servidor
    start_server()