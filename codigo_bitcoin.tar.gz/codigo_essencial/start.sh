#!/bin/bash

# Script de inicialização principal para o Replit
# Este script é executado quando o usuário clica no botão "Run" no Replit

clear
echo "====================================="
echo "    BITCOIN WALLET - INICIALIZAÇÃO   "
echo "====================================="
echo ""
echo "Verificando ambiente..."

# Verificar se o executável está presente
if [ ! -f "BitcoinWallet-2/bitcoinwallet" ]; then
    echo "ERRO: Executável 'bitcoinwallet' não encontrado!"
    echo "Verifique se o executável foi compilado corretamente."
    exit 1
fi

# Garantir permissões de execução
echo "Configurando permissões..."
chmod +x run.sh run_interface.sh show_found_keys.sh restart_server.sh BitcoinWallet-2/bitcoinwallet

# Encerrar qualquer instância anterior do servidor web
echo "Verificando se já existe um servidor web em execução..."
if pgrep -f "python server.py" > /dev/null || pgrep -f "python simple_server.py" > /dev/null || pgrep -f "python basic_server.py" > /dev/null; then
    echo "Encontrado servidor anterior. Encerrando..."
    pkill -f "python server.py" 2>/dev/null
    pkill -f "python simple_server.py" 2>/dev/null
    pkill -f "python basic_server.py" 2>/dev/null
    sleep 2
fi

# Limpar logs anteriores
rm -f server_webview.log 2>/dev/null

# Iniciar o servidor web usando o servidor básico (mais simples e estável)
echo "Iniciando servidor web básico..."
nohup python basic_server.py > /dev/null 2>&1 &
SERVER_PID=$!

# Verificar se o servidor iniciou corretamente
sleep 3
if ! ps -p $SERVER_PID > /dev/null; then
    echo "AVISO: Servidor web básico não iniciou corretamente."
    echo "Tentando iniciar novamente..."
    nohup python basic_server.py > /dev/null 2>&1 &
    SERVER_PID=$!
    
    sleep 2
    if ! ps -p $SERVER_PID > /dev/null; then
        echo "ERRO: Servidor básico falhou. Tentando servidor simplificado..."
        nohup python simple_server.py > /dev/null 2>&1 &
        SERVER_PID=$!
        
        sleep 2
        if ! ps -p $SERVER_PID > /dev/null; then
            echo "ERRO: Servidor simplificado falhou. Tentando servidor original..."
            nohup python server.py > /dev/null 2>&1 &
            SERVER_PID=$!
            
            sleep 2
            if ! ps -p $SERVER_PID > /dev/null; then
                echo "ERRO CRÍTICO: Não foi possível iniciar nenhum servidor web."
                echo "Execute manualmente ./restart_server.sh para tentar novamente."
            else
                echo "Servidor web original iniciado com sucesso como último recurso (PID: $SERVER_PID)."
                echo "Acesse a interface web na aba 'Webview' do Replit."
            fi
        else
            echo "Servidor web simplificado iniciado com sucesso como fallback (PID: $SERVER_PID)."
            echo "Acesse a interface web na aba 'Webview' do Replit."
        fi
    else
        echo "Servidor web básico iniciado com sucesso na segunda tentativa (PID: $SERVER_PID)."
        echo "Acesse a interface web na aba 'Webview' do Replit."
    fi
else
    echo "Servidor web básico iniciado com sucesso (PID: $SERVER_PID)."
    echo "Acesse a interface web na aba 'Webview' do Replit."
fi

# Criar um arquivo para indicar qual PID está rodando o servidor
echo $SERVER_PID > .server_pid

echo ""
echo "====================================="
echo "       BITCOIN WALLET - MENU         "
echo "====================================="
echo ""
echo "Para executar o programa Bitcoin Wallet, você tem as seguintes opções:"
echo ""
echo "1. Usar a interface interativa completa"
echo "2. Usar a interface simplificada"
echo "3. Visualizar chaves encontradas"
echo "4. Reiniciar o servidor web"
echo "5. Sair"
echo ""
echo "====================================="
echo -n "Selecione uma opção (1-5): "
read OPTION

case $OPTION in
    1)
        echo "Iniciando interface completa..."
        ./run.sh
        ;;
    2)
        echo "Iniciando interface simplificada..."
        ./run_interface.sh
        ;;
    3)
        echo "Exibindo chaves encontradas..."
        ./show_found_keys.sh
        ;;
    4)
        echo "Reiniciando servidor web..."
        ./restart_server.sh
        ;;
    5)
        echo "Saindo..."
        ;;
    *)
        echo "Opção inválida. Execute manualmente um dos comandos acima."
        ;;
esac

echo ""
echo "====================================="
echo "      IMPORTANTE - SERVIDOR WEB      "
echo "====================================="
echo ""
echo "O servidor web continua rodando em segundo plano."
echo "Para acessá-lo, use a aba 'Webview' do Replit."
echo ""
echo "Se precisar reiniciar o servidor web, use:"
echo "./restart_server.sh"
echo ""
echo "Para executar o Bitcoin Wallet novamente, use:"
echo "./run.sh"
echo ""
echo "====================================="
echo ""
echo "Pressione Enter para encerrar esta janela..."
read

# NÃO encerramos o servidor web aqui para permitir que ele continue rodando
# em segundo plano, disponibilizando a interface web

echo "Script de inicialização encerrado."
exit 0