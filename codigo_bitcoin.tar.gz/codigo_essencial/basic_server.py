#!/usr/bin/env python3
import http.server
import socketserver
import os
import sys
import time
import datetime

# Configurações básicas
PORT = 8080
log_file = "server_webview.log"

# Inicialização
start_time = datetime.datetime.now()
print(f"[{start_time}] Iniciando servidor básico...")
with open(log_file, "w") as f:
    f.write(f"[{start_time}] Iniciando servidor básico na porta {PORT}...\n")

# Registrar PID
try:
    pid = os.getpid()
    with open(".server_pid", "w") as f:
        f.write(str(pid))
    print(f"PID {pid} registrado")
except:
    print("Erro ao registrar PID")

# Criar arquivo HTML básico
html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="30">
    <title>Bitcoin Wallet Interface</title>
    <style>
        body {{ font-family: Arial; max-width: 800px; margin: 0 auto; padding: 20px; }}
        h1 {{ color: #f7931a; }}
        .info {{ background-color: #e9f5ff; padding: 15px; border-radius: 5px; margin: 15px 0; }}
        .code {{ background-color: #272822; color: white; font-family: monospace; padding: 10px; border-radius: 4px; }}
    </style>
</head>
<body>
    <h1>Bitcoin Wallet Interface</h1>
    
    <div class="info">
        <p><strong>Servidor:</strong> Ativo desde {start_time.strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p><strong>PID:</strong> {os.getpid()}</p>
        <p>Esta página será atualizada a cada 30 segundos automaticamente.</p>
    </div>
    
    <h2>Instruções:</h2>
    <p>Execute um dos seguintes comandos no console:</p>
    <div class="code">./run.sh</div>
    <p>ou</p>
    <div class="code">./run_interface.sh</div>
    
    <p>Para visualizar chaves encontradas:</p>
    <div class="code">./show_found_keys.sh</div>
    
    <p>Se precisar reiniciar o servidor:</p>
    <div class="code">./restart_server.sh</div>
    
    <div class="info">
        <p>Última atualização: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
    </div>
</body>
</html>
"""

with open("index.html", "w") as f:
    f.write(html_content)
print("Arquivo HTML criado com sucesso")

# Definir handler
handler = http.server.SimpleHTTPRequestHandler

# Iniciar servidor
try:
    with socketserver.TCPServer(("0.0.0.0", PORT), handler) as httpd:
        print(f"Servidor iniciado na porta {PORT}")
        with open(log_file, "a") as f:
            f.write(f"[{datetime.datetime.now()}] Servidor iniciado com sucesso na porta {PORT}\n")
        httpd.serve_forever()
except Exception as e:
    print(f"Erro ao iniciar servidor: {str(e)}")
    with open(log_file, "a") as f:
        f.write(f"[{datetime.datetime.now()}] Erro ao iniciar servidor: {str(e)}\n")
    sys.exit(1)